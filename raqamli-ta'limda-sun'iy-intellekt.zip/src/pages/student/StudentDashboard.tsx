import React, { useState, useEffect } from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import { User, GraduationCap, Award, MessageSquare, LogOut, ChevronRight, Home, LayoutDashboard, Loader2, FileText } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { auth, db } from '../../lib/firebase';
import { collection, query, onSnapshot, where, updateDoc, doc } from 'firebase/firestore';
import StudentProfile from './StudentProfile';
import StudentGrades from './StudentGrades';
import StudentCourses from './StudentCourses';
import StudentTests from './StudentTests';
import StudentCertificates from './StudentCertificates';
import ChatSection from '../ChatSection';
import { motion, AnimatePresence } from 'motion/react';

export default function StudentDashboard() {
  const { user, refreshUser } = useAuth();
  const location = useLocation();
  const [unreadCount, setUnreadCount] = useState(0);
  
  const isProfileIncomplete = user && (!user.firstName || !user.lastName || !user.address || !user.phone || !user.birthDate || !user.email);
  const [showCompletionModal, setShowCompletionModal] = useState(false);

  const [formData, setFormData] = useState({
    firstName: user?.firstName || '',
    lastName: user?.lastName || '',
    middleName: user?.middleName || '',
    birthDate: user?.birthDate || '',
    address: user?.address || '',
    email: user?.email && !user.email.includes('@student.uz') ? user.email : '',
    phone: user?.phone || '',
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (user && isProfileIncomplete) {
      setShowCompletionModal(true);
    } else {
      setShowCompletionModal(false);
    }
  }, [user, isProfileIncomplete]);

  useEffect(() => {
    if (!user) return;
    const q = query(
      collection(db, 'messages'),
      where('receiverId', '==', user.uid),
      where('isRead', '==', false)
    );
    const unsub = onSnapshot(q, (snap) => {
      setUnreadCount(snap.docs.length);
    }, (err) => console.error(err));
    return unsub;
  }, [user]);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setSaving(true);
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        ...formData,
        displayName: `${formData.lastName} ${formData.firstName} ${formData.middleName}`.trim()
      });
      await refreshUser();
      setShowCompletionModal(false);
    } catch (err) {
      console.error(err);
      alert('Hatolik yuz berdi saqlashda.');
    } finally {
      setSaving(false);
    }
  };

  const menuItems = [
    { name: 'Profil', path: '/student', icon: User },
    { name: 'Baholar', path: '/student/grades', icon: GraduationCap },
    { name: 'Kurslar', path: '/student/courses', icon: LayoutDashboard },
    { name: 'Testlar', path: '/student/tests', icon: FileText },
    { name: 'Sertifikatlar', path: '/student/certificates', icon: Award },
    { name: 'Aloqa', path: '/student/chat', icon: MessageSquare, badge: unreadCount },
  ];

  const handleLogout = () => auth.signOut();

  return (
    <div className="flex flex-col md:flex-row min-h-[calc(100vh-64px)] bg-gray-50 relative">
      <AnimatePresence>
        {showCompletionModal && (
          <motion.div 
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/60 backdrop-blur-sm"
          >
            <motion.div 
              initial={{ scale: 0.95 }} animate={{ scale: 1 }} exit={{ scale: 0.95 }}
              className="bg-white rounded-3xl p-8 w-full max-w-2xl shadow-2xl relative"
            >
              <h2 className="text-2xl font-black text-gray-900 mb-2">Profil ma'lumotlarini to'ldiring</h2>
              <p className="text-gray-500 mb-6 text-sm font-medium">Davom etish uchu quyidagi ma'lumotlarni to'ldirishingiz shart.</p>
              
              <form onSubmit={handleSaveProfile} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Familiya</label>
                    <input type="text" required value={formData.lastName} onChange={e => setFormData({...formData, lastName: e.target.value})} className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none text-sm font-medium" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Ism</label>
                    <input type="text" required value={formData.firstName} onChange={e => setFormData({...formData, firstName: e.target.value})} className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none text-sm font-medium" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Otasining ismi</label>
                    <input type="text" value={formData.middleName} onChange={e => setFormData({...formData, middleName: e.target.value})} className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none text-sm font-medium" />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Tug'ilgan sana (kun.oy.yil)</label>
                    <input type="date" required value={formData.birthDate} onChange={e => setFormData({...formData, birthDate: e.target.value})} className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none text-sm font-medium" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Telefon raqami</label>
                    <input type="text" required value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none text-sm font-medium" />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Yashash manzili</label>
                    <input type="text" required value={formData.address} onChange={e => setFormData({...formData, address: e.target.value})} className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none text-sm font-medium" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Elektron pochta</label>
                    <input type="email" required value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none text-sm font-medium" />
                  </div>
                </div>

                <div className="pt-4 flex justify-end">
                  <button disabled={saving} type="submit" className="flex items-center gap-2 px-8 py-3 bg-blue-600 text-white rounded-xl font-bold shadow-lg shadow-blue-200 hover:bg-blue-700 transition-colors disabled:opacity-50">
                    {saving && <Loader2 className="w-4 h-4 animate-spin" />}
                    Saqlash
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <aside className="w-full md:w-72 bg-white border-r border-gray-100 flex flex-col p-6 shadow-sm">
        <div className="flex items-center gap-4 mb-10 pb-6 border-b border-gray-50">
          <div className="w-12 h-12 rounded-2xl bg-blue-600 flex items-center justify-center text-white shadow-lg shadow-blue-100">
            {user?.photoURL ? (
              <img src={user.photoURL || null} alt="Avatar" className="w-full h-full rounded-2xl object-cover" />
            ) : (
              <User className="h-6 w-6" />
            )}
          </div>
          <div className="overflow-hidden">
            <p className="font-bold text-gray-900 truncate">{user?.displayName}</p>
            <p className="text-xs text-gray-500 font-medium tracking-wide uppercase">Talaba</p>
          </div>
        </div>

        <nav className="flex-1 space-y-2">
          {menuItems.map((item) => {
            const active = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-4 py-3.5 rounded-2xl transition-all group ${
                  active 
                    ? 'bg-blue-600 text-white shadow-xl shadow-blue-100' 
                    : 'text-gray-600 hover:bg-gray-50 hover:text-blue-600'
                }`}
              >
                <item.icon className="h-5 w-5" />
                <span className="font-semibold flex-1">{item.name}</span>
                {item.badge && item.badge > 0 ? (
                   <span className="w-5 h-5 rounded-full bg-red-500 text-white flex items-center justify-center text-xs font-bold shadow-md">
                     {item.badge}
                   </span>
                ) : (
                  <>
                    {active && <ChevronRight className="h-4 w-4" />}
                    {!active && <ChevronRight className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity" />}
                  </>
                )}
              </Link>
            );
          })}
        </nav>

        <div className="mt-auto pt-6 space-y-2">
          <Link
            to="/"
            className="flex items-center gap-3 px-4 py-3 rounded-xl text-gray-600 hover:bg-gray-50 transition-colors font-medium"
          >
            <Home className="h-5 w-5" />
            Saytga qaytish
          </Link>
          <button
            onClick={handleLogout}
            className="flex items-center gap-3 px-4 py-3 rounded-xl text-red-500 hover:bg-red-50 transition-colors font-medium w-full text-left"
          >
            <LogOut className="h-5 w-5" />
            Tizimdan chiqish
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-4 md:p-10 overflow-y-auto">
        <motion.div
           initial={{ opacity: 0, y: 10 }}
           animate={{ opacity: 1, y: 0 }}
           key={location.pathname}
           className="max-w-5xl mx-auto"
        >
          <Routes>
            <Route path="/" element={<StudentProfile />} />
            <Route path="/grades" element={<StudentGrades />} />
            <Route path="/courses" element={<StudentCourses />} />
            <Route path="/tests" element={<StudentTests />} />
            <Route path="/certificates" element={<StudentCertificates />} />
            <Route path="/chat" element={<ChatSection />} />
          </Routes>
        </motion.div>
      </main>
    </div>
  );
}
