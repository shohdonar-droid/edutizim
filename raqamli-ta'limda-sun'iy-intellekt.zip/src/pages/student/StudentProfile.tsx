import React, { useState, useEffect } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { db } from '../../lib/firebase';
import { doc, updateDoc, getDocs, collection, query, where } from 'firebase/firestore';
import { Camera, Save, Loader2, Mail, Phone, Calendar, User as UserIcon, Building, Users } from 'lucide-react';
import { Department, Group } from '../../types';

export default function StudentProfile() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    displayName: user?.displayName || '',
    phone: user?.phone || '',
    birthDate: user?.birthDate || '',
    photoURL: user?.photoURL || '',
    departmentId: user?.departmentId || '',
    groupId: user?.groupId || '',
  });

  const [departments, setDepartments] = useState<Department[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);

  useEffect(() => {
    async function loadDeptsAndGroups() {
      if (!user?.teacherId) return;
      try {
        const dSnap = await getDocs(query(collection(db, 'departments'), where('creatorId', '==', user.teacherId)));
        const depts = dSnap.docs.map(d => ({ id: d.id, ...d.data() } as Department));
        setDepartments(depts);

        const gSnap = await getDocs(query(collection(db, 'groups'), where('creatorId', '==', user.teacherId)));
        const grps = gSnap.docs.map(g => ({ id: g.id, ...g.data() } as Group));
        setGroups(grps);
      } catch (err) {
        console.error(err);
      }
    }
    loadDeptsAndGroups();
  }, [user]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setLoading(true);
    
    const deptName = departments.find(d => d.id === formData.departmentId)?.name || '';
    const grpName = groups.find(g => g.id === formData.groupId)?.name || '';

    try {
      await updateDoc(doc(db, 'users', user.uid), {
        ...formData,
        departmentName: deptName,
        groupName: grpName
      });
      alert('Ma\'lumotlar yangilandi!');
      window.location.reload(); // Quick refresh to update context
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const filteredGroups = groups.filter(g => g.departmentId === formData.departmentId);

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-3xl font-bold text-gray-900 tracking-tight">Shaxsiy profil</h1>
        <p className="text-gray-500 mt-1">Platformadagi ma'lumotlaringizni boshqaring.</p>
      </header>

      <form onSubmit={handleSave} className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Profile Picture Card */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-3xl p-8 border border-gray-100 shadow-sm flex flex-col items-center">
            <div className="relative group cursor-pointer">
              <div className="w-40 h-40 rounded-3xl bg-blue-50 flex items-center justify-center text-blue-600 overflow-hidden ring-4 ring-white shadow-2xl">
                {formData.photoURL ? (
                  <img src={formData.photoURL || null} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  <UserIcon className="h-16 w-16" />
                )}
              </div>
              <div className="absolute inset-0 bg-blue-600/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity rounded-3xl">
                <Camera className="h-8 w-8 text-white" />
              </div>
            </div>
            <div className="mt-8 w-full">
              <label className="block text-sm font-semibold text-gray-700 mb-2 text-center uppercase tracking-wider">Rasm URL</label>
              <input
                type="text"
                className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm focus:ring-2 focus:ring-blue-500 transition-all text-center"
                placeholder="https://example.com/avatar.jpg"
                value={formData.photoURL}
                onChange={(e) => setFormData({ ...formData, photoURL: e.target.value })}
              />
            </div>
            <p className="mt-6 text-xs text-gray-400 text-center leading-relaxed">
              O'quv sertifikatlarida aynan shu ism vva rasm aks etadi.
            </p>
          </div>
        </div>

        {/* Info Card */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-3xl p-10 border border-gray-100 shadow-sm space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="flex items-center gap-2 text-sm font-bold text-gray-700 mb-2 uppercase tracking-wide">
                  <UserIcon className="h-4 w-4 text-gray-400" />
                  To'liq ism (FISH)
                </label>
                <input
                  type="text"
                  required
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-500 transition-all font-medium"
                  value={formData.displayName}
                  onChange={(e) => setFormData({ ...formData, displayName: e.target.value })}
                />
              </div>
              <div>
                <label className="flex items-center gap-2 text-sm font-bold text-gray-700 mb-2 uppercase tracking-wide">
                  <Mail className="h-4 w-4 text-gray-400" />
                  Email
                </label>
                <input
                  type="email"
                  disabled
                  className="w-full px-4 py-3 rounded-xl border border-gray-100 bg-gray-50 text-gray-500 font-medium cursor-not-allowed"
                  value={user?.email}
                />
              </div>
              <div>
                <label className="flex items-center gap-2 text-sm font-bold text-gray-700 mb-2 uppercase tracking-wide">
                  <Phone className="h-4 w-4 text-gray-400" />
                  Telefon raqam
                </label>
                <input
                  type="tel"
                  placeholder="+998 90 123 45 67"
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-500 transition-all font-medium"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                />
              </div>
              <div>
                <label className="flex items-center gap-2 text-sm font-bold text-gray-700 mb-2 uppercase tracking-wide">
                  <Calendar className="h-4 w-4 text-gray-400" />
                  Tug'ilgan sana
                </label>
                <input
                  type="date"
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-500 transition-all font-medium"
                  value={formData.birthDate}
                  onChange={(e) => setFormData({ ...formData, birthDate: e.target.value })}
                />
              </div>
              <div>
                <label className="flex items-center gap-2 text-sm font-bold text-gray-700 mb-2 uppercase tracking-wide">
                  <Building className="h-4 w-4 text-gray-400" />
                  Yo'nalish
                </label>
                <select
                  required
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-500 transition-all font-medium"
                  value={formData.departmentId}
                  onChange={(e) => setFormData({ ...formData, departmentId: e.target.value, groupId: '' })}
                >
                  <option value="">Tanlang</option>
                  {departments.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="flex items-center gap-2 text-sm font-bold text-gray-700 mb-2 uppercase tracking-wide">
                  <Users className="h-4 w-4 text-gray-400" />
                  Guruh
                </label>
                <select
                  required
                  disabled={!formData.departmentId}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-500 transition-all font-medium disabled:opacity-50"
                  value={formData.groupId}
                  onChange={(e) => setFormData({ ...formData, groupId: e.target.value })}
                >
                  <option value="">Tanlang</option>
                  {filteredGroups.map((g) => (
                    <option key={g.id} value={g.id}>
                      {g.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="pt-6 border-t border-gray-50 flex justify-end">
              <button
                disabled={loading}
                type="submit"
                className="flex items-center gap-2 px-8 py-3.5 rounded-2xl bg-blue-600 text-white font-bold shadow-lg shadow-blue-100 hover:bg-blue-700 transition-all active:scale-95 disabled:opacity-70"
              >
                {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Save className="h-5 w-5" />}
                O'zgarishlarni saqlash
              </button>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}
