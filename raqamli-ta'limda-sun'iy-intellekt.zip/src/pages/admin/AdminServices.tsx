import { useState } from 'react';
import { Loader2, MonitorPlay, Sparkles, Download, FileText, BookOpen, ClipboardList, PenTool } from 'lucide-react';
import { generatePresentation as genPresentation, generateDynamicTest, generateDocument } from '../../services/geminiService';
import Markdown from 'react-markdown';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import remarkGfm from 'remark-gfm';
import 'katex/dist/katex.min.css';
import pptxgen from "pptxgenjs";
import domtoimage from 'dom-to-image-more';
import jsPDF from 'jspdf';

import { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType } from 'docx';
import { saveAs } from 'file-saver';

export default function AdminServices() {
  type TabType = 'presentation' | 'kurs_ishi' | 'dars_ishlanma' | 'hisobot' | 'test' | 'maqola';
  const [activeTab, setActiveTab] = useState<TabType>('presentation');

  // Unified State
  const [topic, setTopic] = useState('');
  const [itemCount, setItemCount] = useState(10);
  const [pageCount, setPageCount] = useState(20);
  const [additionalInfo, setAdditionalInfo] = useState('');
  const [journalType, setJournalType] = useState<'international' | 'uzbekistan'>('uzbekistan');
  const [loading, setLoading] = useState(false);
  
  // Results
  const [presentation, setPresentation] = useState<any[] | null>(null);
  const [documentContent, setDocumentContent] = useState<{title: string, content: string} | null>(null);
  const [quizContent, setQuizContent] = useState<any[] | null>(null);

  const handleGenerate = async () => {
    if (!topic) return;
    setLoading(true);
    try {
      if (activeTab === 'presentation') {
        const slides = await genPresentation(topic, itemCount);
        setPresentation(slides);
      } else if (activeTab === 'test') {
        const quiz = await generateDynamicTest(topic, itemCount, additionalInfo);
        setQuizContent(quiz);
      } else {
        const doc = await generateDocument(topic, activeTab, {
          pageCount,
          context: additionalInfo,
          journalType
        });
        setDocumentContent(doc);
      }
      alert('Muvaffaqiyatli tuzildi!');
    } catch (err) {
      console.error(err);
      alert('Xatolik yuz berdi');
    } finally {
      setLoading(false);
    }
  };

  const downloadWord = async () => {
    setLoading(true);
    try {
      let doc: Document;
      let filename = topic || "dokument";

      if (activeTab === 'test' && quizContent) {
        doc = new Document({
          sections: [{
            properties: {},
            children: [
              new Paragraph({
                text: `${topic} - Test savollari`,
                heading: HeadingLevel.HEADING_1,
                alignment: AlignmentType.CENTER,
              }),
              ...quizContent.flatMap((q, i) => [
                new Paragraph({
                  children: [
                    new TextRun({ text: `${i + 1}. ${q.text}`, bold: true }),
                  ],
                  spacing: { before: 200 },
                }),
                ...q.options.map((opt: string, optI: number) => 
                  new Paragraph({
                    text: `${String.fromCharCode(65 + optI)}) ${opt}`,
                    indent: { left: 720 },
                  })
                ),
                new Paragraph({
                  children: [
                    new TextRun({ text: `To'g'ri javob: ${String.fromCharCode(65 + q.correctIdx)}`, italics: true, color: "2D862D" }),
                  ],
                  spacing: { before: 100 },
                })
              ])
            ],
          }],
        });
        filename += "_test";
      } else if (documentContent) {
        // Simple MD to Docx paragraphs (roughly)
        const contentLines = documentContent.content.split('\n');
        doc = new Document({
          sections: [{
            properties: {},
            children: [
              new Paragraph({
                text: documentContent.title,
                heading: HeadingLevel.HEADING_1,
                alignment: AlignmentType.CENTER,
              }),
              ...contentLines.map(line => {
                const cleanLine = line.replace(/[#*`]/g, '').trim();
                if (!cleanLine) return new Paragraph({ text: "" });
                
                return new Paragraph({
                  children: [new TextRun(cleanLine)],
                  spacing: { before: 120 },
                });
              })
            ],
          }],
        });
      } else {
        throw new Error("Kontent topilmadi");
      }

      const blob = await Packer.toBlob(doc);
      saveAs(blob, `${filename}.docx`);
    } catch (err) {
      console.error('Word export xatolik:', err);
      alert('Word formatda yuklab olishda xatolik');
    } finally {
      setLoading(false);
    }
  };

  const downloadPPT = async () => {
    if (!presentation) return;
    setLoading(true);
    try {
      const pptx = new pptxgen();
      pptx.author = 'AI Studio';
      pptx.company = 'AI Studio';
      pptx.title = topic;
      
      // Create master slide for branding
      pptx.defineSlideMaster({
        title: "MASTER_SLIDE",
        background: { color: "FFFFFF" },
        margin: [0, 0, 0, 0]
      });

      // Function to delay execution to avoid rate limits
      const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

      for (let i = 0; i < presentation.length; i++) {
        await sleep(1500); // Wait 1.5 seconds per slide to allow image caching and avoid dom-to-image rate limiting
        const slideElement = document.getElementById(`slide-preview-${i}`);
        if (slideElement) {
          // ensure equations and images are captured, ignoring failed images
          const dataUrl = await domtoimage.toPng(slideElement, {
            quality: 1,
            bgcolor: '#ffffff',
            imagePlaceholder: 'data:image/svg+xml;charset=utf-8,%3Csvg xmlns="http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg" width="800" height="600"%3E%3Crect width="800" height="600" fill="%23f3f4f6"%2F%3E%3Ctext x="50%25" y="50%25" dominant-baseline="middle" text-anchor="middle" font-family="sans-serif" font-size="24px" fill="%239ca3af"%3ERasm yuklanmadi%3C%2Ftext%3E%3C%2Fsvg%3E'
          });
          
          const s = pptx.addSlide({ masterName: "MASTER_SLIDE" });
          s.addImage({ data: dataUrl, x:0, y:0, w:'100%', h:'100%', sizing: { type: 'contain', w: 10, h: 5.625 } });
        }
      }

      await pptx.writeFile({ fileName: `${topic}.pptx` });
    } catch (err) {
      console.error(err);
      alert('Taqdimotni yuklashda xatolik');
    } finally {
      setLoading(false);
    }
  };

  const downloadPDF = async (elementId: string, filename: string) => {
    const el = document.getElementById(elementId);
    if (!el) return;
    setLoading(true);
    try {
      const dataUrl = await domtoimage.toPng(el, {
        quality: 1,
        bgcolor: '#ffffff',
        imagePlaceholder: 'data:image/svg+xml;charset=utf-8,%3Csvg xmlns="http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg" width="800" height="600"%3E%3Crect width="800" height="600" fill="%23f3f4f6"%2F%3E%3Ctext x="50%25" y="50%25" dominant-baseline="middle" text-anchor="middle" font-family="sans-serif" font-size="24px" fill="%239ca3af"%3ERasm yuklanmadi%3C%2Ftext%3E%3C%2Fsvg%3E'
      });
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgProps = pdf.getImageProperties(dataUrl);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
      let heightLeft = pdfHeight;
      let position = 0;

      pdf.addImage(dataUrl, 'PNG', 0, position, pdfWidth, pdfHeight);
      heightLeft -= pdf.internal.pageSize.getHeight();

      while (heightLeft >= 0) {
        position = heightLeft - pdfHeight;
        pdf.addPage();
        pdf.addImage(dataUrl, 'PNG', 0, position, pdfWidth, pdfHeight);
        heightLeft -= pdf.internal.pageSize.getHeight();
      }

      pdf.save(`${filename}.pdf`);
    } catch (err) {
      console.error('PDF export xatolik:', err);
      alert('Yuklab olishda xatolik yuz berdi');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-10">
      <header className="flex justify-between items-center">
        <div>
          <h1 className="text-4xl font-black text-gray-900 tracking-tight">Xizmatlar</h1>
          <p className="text-gray-500 mt-2 text-lg">Qo'shimcha sun'iy intellekt xizmatlari va imkoniyatlar.</p>
        </div>
      </header>

      <div className="flex bg-white rounded-2xl p-1.5 border border-gray-100 shadow-sm w-fit overflow-x-auto">
        <button
          onClick={() => setActiveTab('presentation')}
          className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all ${activeTab === 'presentation' ? 'bg-indigo-600 text-white' : 'text-gray-400 hover:text-gray-600'}`}
        >
          <MonitorPlay className="w-5 h-5" /> Taqdimot
        </button>
        <button
          onClick={() => setActiveTab('kurs_ishi')}
          className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all ${activeTab === 'kurs_ishi' ? 'bg-indigo-600 text-white' : 'text-gray-400 hover:text-gray-600'}`}
        >
          <BookOpen className="w-5 h-5" /> Kurs ishi
        </button>
        <button
          onClick={() => setActiveTab('dars_ishlanma')}
          className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all ${activeTab === 'dars_ishlanma' ? 'bg-indigo-600 text-white' : 'text-gray-400 hover:text-gray-600'}`}
        >
          <FileText className="w-5 h-5" /> Dars ishlanma
        </button>
        <button
          onClick={() => setActiveTab('hisobot')}
          className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all ${activeTab === 'hisobot' ? 'bg-indigo-600 text-white' : 'text-gray-400 hover:text-gray-600'}`}
        >
          <ClipboardList className="w-5 h-5" /> Hisobot
        </button>
        <button
          onClick={() => setActiveTab('test')}
          className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all ${activeTab === 'test' ? 'bg-indigo-600 text-white' : 'text-gray-400 hover:text-gray-600'}`}
        >
          <PenTool className="w-5 h-5" /> Test yaratish
        </button>
        <button
          onClick={() => setActiveTab('maqola')}
          className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all ${activeTab === 'maqola' ? 'bg-indigo-600 text-white' : 'text-gray-400 hover:text-gray-600'}`}
        >
          <FileText className="w-5 h-5" /> Maqola
        </button>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-10 items-start relative">
        <div className="bg-white rounded-3xl p-10 border border-gray-100 shadow-sm space-y-8">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 flex items-center justify-center text-indigo-600">
              <Sparkles className="h-6 w-6" />
            </div>
            <div>
              <h3 className="text-2xl font-black text-gray-900">Yaratish</h3>
              <p className="text-gray-500 text-sm mt-1">Sun'iy intellekt yordamida kontent tuzish.</p>
            </div>
          </div>

          <div className="space-y-6">
            <div className="space-y-2">
              <label className="block text-xs font-black text-gray-400 uppercase tracking-widest">
                {activeTab === 'presentation' ? 'Taqdimot mavzusi' : 
                 activeTab === 'test' ? 'Test nomi / Mavzusi' :
                 activeTab === 'kurs_ishi' ? 'Kurs ishi mavzusi' :
                 activeTab === 'maqola' ? 'Maqola mavzusi' :
                 activeTab === 'hisobot' ? 'Hisobot nomi' : 'Dars mavzusi'}
              </label>
              <input
                type="text"
                placeholder="Kiriting..."
                value={topic}
                onChange={e => setTopic(e.target.value)}
                className="w-full px-5 py-4 rounded-xl bg-gray-50 border-none focus:ring-2 focus:ring-indigo-600 font-bold text-gray-900 placeholder:text-gray-400"
              />
            </div>

            {activeTab === 'presentation' && (
              <div className="space-y-2">
                <label className="block text-xs font-black text-gray-400 uppercase tracking-widest">Slaydlar soni</label>
                <input
                  type="number"
                  min={1}
                  max={30}
                  value={itemCount}
                  onChange={e => setItemCount(parseInt(e.target.value) || 1)}
                  className="w-full px-5 py-4 rounded-xl bg-gray-50 border-none focus:ring-2 focus:ring-indigo-600 font-bold text-gray-900"
                />
              </div>
            )}

            {activeTab === 'test' && (
              <div className="space-y-2">
                <label className="block text-xs font-black text-gray-400 uppercase tracking-widest">Savollar soni</label>
                <input
                  type="number"
                  min={1}
                  max={50}
                  value={itemCount}
                  onChange={e => setItemCount(parseInt(e.target.value) || 1)}
                  className="w-full px-5 py-4 rounded-xl bg-gray-50 border-none focus:ring-2 focus:ring-indigo-600 font-bold text-gray-900"
                />
              </div>
            )}

            {activeTab === 'kurs_ishi' && (
              <div className="space-y-2">
                <label className="block text-xs font-black text-gray-400 uppercase tracking-widest">Varaqlar soni</label>
                <input
                  type="number"
                  min={1}
                  max={100}
                  value={pageCount}
                  onChange={e => setPageCount(parseInt(e.target.value) || 20)}
                  className="w-full px-5 py-4 rounded-xl bg-gray-50 border-none focus:ring-2 focus:ring-indigo-600 font-bold text-gray-900"
                />
              </div>
            )}

            {(activeTab === 'test' || activeTab === 'hisobot') && (
              <div className="space-y-2">
                <label className="block text-xs font-black text-gray-400 uppercase tracking-widest">
                  {activeTab === 'test' ? 'Qo\'shimcha ma\'lumotlar (ixtiyoriy matndan test tuzish uchun)' : 'Matn (qilingan, qilinayotgan va rejalashtirilgan ishlar)'}
                </label>
                <textarea
                  rows={6}
                  placeholder="Matnni shu yerga kiriting yoki nusxalab tashang..."
                  value={additionalInfo}
                  onChange={e => setAdditionalInfo(e.target.value)}
                  className="w-full px-5 py-4 rounded-xl bg-gray-50 border-none focus:ring-2 focus:ring-indigo-600 font-medium text-gray-900 placeholder:text-gray-400 resize-none shadow-inner"
                />
              </div>
            )}

            {activeTab === 'maqola' && (
              <div className="space-y-2">
                <label className="block text-xs font-black text-gray-400 uppercase tracking-widest">Jurnal turi</label>
                <div className="grid grid-cols-2 gap-4">
                  <button
                    onClick={() => setJournalType('uzbekistan')}
                    className={`py-3 rounded-xl font-bold border-2 transition-all ${journalType === 'uzbekistan' ? 'border-indigo-600 bg-indigo-50 text-indigo-700' : 'border-gray-100 text-gray-400 hover:border-gray-200'}`}
                  >
                    O'zbekiston (OAK)
                  </button>
                  <button
                    onClick={() => setJournalType('international')}
                    className={`py-3 rounded-xl font-bold border-2 transition-all ${journalType === 'international' ? 'border-indigo-600 bg-indigo-50 text-indigo-700' : 'border-gray-100 text-gray-400 hover:border-gray-200'}`}
                  >
                    Xalqaro (Journal)
                  </button>
                </div>
              </div>
            )}

            <button
              onClick={handleGenerate}
              disabled={loading || !topic}
              className="w-full flex items-center justify-center gap-2 py-4 bg-indigo-600 text-white rounded-xl font-black shadow-lg shadow-indigo-100 hover:bg-indigo-700 active:scale-[0.98] transition-all disabled:opacity-50 disabled:active:scale-100"
            >
              {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Sparkles className="h-5 w-5" />}
              {activeTab === 'presentation' 
                ? `${itemCount} TA SLAYDLI TAQDIMOT TUZISH (AI)` 
                : activeTab === 'test' 
                ? `${itemCount} TA TEST SAVOLI TUZISH (AI)`
                : activeTab === 'kurs_ishi'
                ? `KURS ISHI YARATISH (${pageCount} VARAQ)`
                : activeTab === 'dars_ishlanma'
                ? '1 SOATLIK DARS ISHLANMA TAYYORLASH (AI)'
                : activeTab === 'hisobot'
                ? 'HISOBOT TAYYORLASH (AI)'
                : 'ILMIY MAQOLA TAYYORLASH (AI)'
              }
            </button>
          </div>
        </div>

          <div className="bg-white rounded-3xl p-10 border border-gray-100 shadow-sm space-y-8 min-h-[400px] flex flex-col">
             {activeTab === 'presentation' && presentation ? (
               <div className="space-y-6">
                 <div className="flex justify-between items-center">
                   <h3 className="text-xl font-black text-gray-900">Natija:</h3>
                   <button
                     onClick={downloadPPT}
                     className="flex items-center gap-2 px-4 py-2 bg-indigo-50 text-indigo-700 rounded-xl font-bold hover:bg-indigo-100 transition-colors"
                   >
                     <Download className="h-4 w-4" />
                     .ppt Yuklab olish
                   </button>
                 </div>
                 <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2 custom-scrollbar">
                   {presentation.map((slide, i) => (
                     <div key={i} className="p-6 rounded-2xl bg-gray-50 border border-gray-100">
                       <h4 className="font-bold text-indigo-600 mb-2">{slide.title}</h4>
                       <div className="text-gray-600 text-sm leading-relaxed prose prose-sm max-w-none prose-indigo math-compatible">
                         <Markdown 
                           remarkPlugins={[remarkMath, remarkGfm]} 
                           rehypePlugins={[rehypeKatex]}
                           components={{
                             img: ({node, ...props}) => <img {...props} crossOrigin="anonymous" className="rounded-xl max-h-[150px] object-cover my-2 shadow-sm" alt="" />
                           }}
                         >
                           {slide.content}
                         </Markdown>
                       </div>
                     </div>
                   ))}
                 </div>
               </div>
             ) : activeTab === 'test' && quizContent ? (
               <div className="space-y-6">
                 <div className="flex justify-between items-center">
                   <h3 className="text-xl font-black text-gray-900">Natija:</h3>
                   <div className="flex gap-2">
                     <button
                       onClick={() => downloadPDF('pdf-export-container', `${topic}_test`)}
                       className="flex items-center gap-2 px-4 py-2 bg-indigo-50 text-indigo-700 rounded-xl font-bold hover:bg-indigo-100 transition-colors"
                     >
                       <Download className="h-4 w-4" /> .pdf
                     </button>
                     <button
                       onClick={downloadWord}
                       className="flex items-center gap-2 px-4 py-2 bg-blue-50 text-blue-700 rounded-xl font-bold hover:bg-blue-100 transition-colors"
                     >
                       <FileText className="h-4 w-4" /> .docx
                     </button>
                   </div>
                 </div>
                 <div id="pdf-export-container" className="space-y-4 max-h-[500px] overflow-y-auto pr-2 custom-scrollbar p-4 bg-white">
                   <h2 className="text-2xl font-bold text-center mb-6">{topic} - Test savollari</h2>
                   {quizContent.map((q, i) => (
                     <div key={i} className="p-4 rounded-xl bg-gray-50 border border-gray-100 break-inside-avoid">
                       <h4 className="font-bold text-gray-900 mb-3">{i+1}. {q.text}</h4>
                       <div className="space-y-2">
                         {q.options.map((opt: string, optI: number) => (
                           <div key={optI} className={`p-3 rounded-lg text-sm ${q.correctIdx === optI ? 'bg-green-100 border-green-200 text-green-800 font-medium' : 'bg-white border-gray-200 text-gray-600'} border`}>
                             {String.fromCharCode(65 + optI)}) {opt}
                           </div>
                         ))}
                       </div>
                     </div>
                   ))}
                 </div>
               </div>
             ) : (activeTab === 'kurs_ishi' || activeTab === 'dars_ishlanma' || activeTab === 'hisobot' || activeTab === 'maqola') && documentContent ? (
               <div className="space-y-6 flex flex-col h-full">
                 <div className="flex justify-between items-center">
                   <h3 className="text-xl font-black text-gray-900">Natija:</h3>
                   <div className="flex gap-2">
                     <button
                       onClick={() => downloadPDF('doc-export-container', topic)}
                       className="flex items-center gap-2 px-4 py-2 bg-indigo-50 text-indigo-700 rounded-xl font-bold hover:bg-indigo-100 transition-colors"
                     >
                       <Download className="h-4 w-4" /> .pdf
                     </button>
                     <button
                       onClick={downloadWord}
                       className="flex items-center gap-2 px-4 py-2 bg-blue-50 text-blue-700 rounded-xl font-bold hover:bg-blue-100 transition-colors"
                     >
                       <FileText className="h-4 w-4" /> .docx
                     </button>
                   </div>
                 </div>
                 <div id="doc-export-container" className="bg-gray-50 p-8 rounded-2xl border border-gray-100 max-h-[500px] overflow-y-auto custom-scrollbar">
                   <h1 className="text-3xl font-black text-center mb-8">{documentContent.title}</h1>
                   <div className="prose prose-indigo max-w-none text-gray-700 leading-relaxed math-compatible">
                     <Markdown
                       remarkPlugins={[remarkMath, remarkGfm]}
                       rehypePlugins={[rehypeKatex]}
                       components={{
                         img: ({node, ...props}) => <img {...props} crossOrigin="anonymous" className="rounded-xl max-h-[300px] object-cover mx-auto my-4 shadow-sm" alt="" />
                       }}
                     >
                       {documentContent.content}
                     </Markdown>
                   </div>
                 </div>
               </div>
             ) : (
               <div className="flex-1 flex flex-col items-center justify-center h-full text-center opacity-30 mt-20">
                 <Sparkles className="h-16 w-16 mb-4 text-gray-300" />
                 <p className="font-bold text-gray-400">Hozircha natija shakllantirilmagan.</p>
                 <p className="text-sm">Parametrlarni kiritib tugmani bosing.</p>
               </div>
             )}
          </div>
        </div>

      {/* Hidden Render Area for PPTX Generation */}
      <div className="absolute top-[-9999px] left-[-9999px] pointer-events-none opacity-0 font-serif">
         {presentation && presentation.map((slide, i) => (
           <div 
             key={`export-${i}`} 
             id={`slide-preview-${i}`} 
             className="w-[1024px] h-[576px] bg-white p-12 flex flex-col justify-start items-start"
             style={{ boxSizing: 'border-box' }}
           >
             <h2 className="text-4xl font-black text-indigo-900 mb-8 w-full border-b pb-4">{slide.title}</h2>
             <div className="text-gray-800 text-2xl leading-relaxed prose prose-2xl max-w-none prose-indigo math-compatible w-full flex-1 overflow-hidden" style={{ columns: (slide.content || '').length > 400 ? 2 : 1, columnGap: '3rem' }}>
               <Markdown 
                 remarkPlugins={[remarkMath, remarkGfm]} 
                 rehypePlugins={[rehypeKatex]}
                 components={{
                   img: ({node, ...props}) => <img {...props} crossOrigin="anonymous" className="rounded-2xl max-h-[250px] object-cover my-4 shadow-md" alt="" />
                 }}
               >
                 {slide.content}
               </Markdown>
             </div>
           </div>
         ))}
      </div>
    </div>
  );
}
