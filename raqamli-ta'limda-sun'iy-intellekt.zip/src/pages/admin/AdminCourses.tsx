import { useState, useEffect } from 'react';
import { db } from '../../lib/firebase';
import { collection, getDocs, addDoc, doc, updateDoc, deleteDoc, serverTimestamp, query, where, onSnapshot } from 'firebase/firestore';
import { Course, Module, Department, Group, UserProfile } from '../../types';
import { MultiSelectDropdown } from '../../components/MultiSelectDropdown';
import { Plus, Edit, Trash2, Loader2, Book, Layout, Save, X, Database, PlayCircle } from 'lucide-react';
import { seedCourses } from './seed_courses';

export default function AdminCourses() {
  const [courses, setCourses] = useState<Course[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [teachers, setTeachers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [seedLoading, setSeedLoading] = useState(false);
  const [editingCourse, setEditingCourse] = useState<Partial<Course> | null>(null);
  const [activeTab, setActiveTab] = useState<'base' | 'orgs'>('base');

  useEffect(() => {
    loadCourses();
    
    // Fetch all depts, groups and teachers (organizations)
    const unsubDepts = onSnapshot(collection(db, 'departments'), (snap) => {
      setDepartments(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Department)));
    });
    const unsubGroups = onSnapshot(collection(db, 'groups'), (snap) => {
      setGroups(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Group)));
    });
    const unsubTeachers = onSnapshot(query(collection(db, 'users'), where('role', '==', 'teacher')), (snap) => {
      setTeachers(snap.docs.map(doc => ({ uid: doc.id, ...doc.data() } as UserProfile)));
    });

    return () => { unsubDepts(); unsubGroups(); unsubTeachers(); };
  }, []);

  const loadCourses = async () => {
    const snap = await getDocs(collection(db, 'courses'));
    setCourses(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Course)));
    setLoading(false);
  };

  const handleSeed = async () => {
    if(!confirm("Yangi 7 ta kurs yaratilsinmi?")) return;
    setSeedLoading(true);
    try {
       await seedCourses();
       await loadCourses();
       alert("Kurslar yaratildi!");
    } catch(err) {
       console.error(err);
    } finally {
       setSeedLoading(false);
    }
  };

  const handleSave = async () => {
    if (!editingCourse?.title) return;
    setLoading(true);

    try {
      if (editingCourse.id) {
        await updateDoc(doc(db, 'courses', editingCourse.id), editingCourse);
      } else {
        await addDoc(collection(db, 'courses'), {
          ...editingCourse,
          modules: editingCourse.modules || Array(5).fill(null).map((_, i) => ({
            id: `m${i+1}`,
            title: i === 4 ? `Yakuniy Imtihon` : `Modul ${i+1}`,
            content: 'Darslik matni bu yerda bo\'ladi...',
            videoUrl: ''
          })),
          createdAt: serverTimestamp()
        });
      }
      setEditingCourse(null);
      loadCourses();
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Kursni o\'chirishni xohlaysizmi?')) return;
    try {
      await deleteDoc(doc(db, 'courses', id));
      loadCourses();
    } catch(err: any) {
      console.error(err);
      alert('Xatolik yuz berdi: ' + err.message);
    }
  };

  const updateModule = (index: number, field: keyof Module, value: string) => {
     if(!editingCourse?.modules) return;
     const newModules = [...editingCourse.modules];
     newModules[index] = { ...newModules[index], [field]: value };
     setEditingCourse({ ...editingCourse, modules: newModules });
  };

  return (
    <div className="space-y-10">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h1 className="text-4xl font-black text-gray-900 tracking-tight">Kurslar boshqaruvi</h1>
          <p className="text-gray-500 mt-2 text-lg">Yangi kurslar yarating va mavjudlarini tahrirlang.</p>
        </div>
        <div className="flex gap-4">
           <button
             onClick={() => setEditingCourse({ 
                 title: '', description: '', thumbnail: '', 
                 modules: Array(5).fill(null).map((_, i) => ({
                   id: `m${i+1}`, title: i === 4 ? 'Yakuniy Imtihon' : `Modul ${i+1}`, content: '', videoUrl: ''
                 })) 
             })}
             className="flex items-center gap-2 px-8 py-4 bg-gray-900 text-white rounded-2xl font-black shadow-2xl hover:bg-black transition-all"
           >
             <Plus className="h-5 w-5" />
             YANGI KURS
           </button>
        </div>
      </header>

      <div className="flex bg-gray-100 p-1.5 rounded-2xl w-max">
         <button
            onClick={() => setActiveTab('base')}
            className={`px-6 py-3 rounded-xl font-bold text-sm transition-all flex items-center gap-2 ${activeTab === 'base' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
         >
            <Book className="w-4 h-4" />
            Asosiy Kurslar
         </button>
         <button
            onClick={() => setActiveTab('orgs')}
            className={`px-6 py-3 rounded-xl font-bold text-sm transition-all flex items-center gap-2 ${activeTab === 'orgs' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
         >
            <Database className="w-4 h-4" />
            Tashkilot Kurslari
         </button>
      </div>

      {editingCourse && (
        <div className="bg-white rounded-3xl p-10 border-4 border-blue-100 shadow-2xl space-y-8 animate-in fade-in slide-in-from-top-4">
          <div className="flex justify-between items-center">
             <h2 className="text-2xl font-black text-gray-900">{editingCourse.id ? 'Kursni tahrirlash' : 'Yangi kurs yaratish'}</h2>
             <button onClick={() => setEditingCourse(null)} className="p-2 hover:bg-gray-100 rounded-lg text-gray-400">
                <X className="h-6 w-6" />
             </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <label className="block text-xs font-black text-gray-400 uppercase tracking-widest">Kurs nomi</label>
              <input
                type="text"
                className="w-full px-5 py-4 rounded-xl bg-gray-50 border-none focus:ring-2 focus:ring-blue-600 font-bold"
                value={editingCourse.title}
                onChange={(e) => setEditingCourse({ ...editingCourse, title: e.target.value })}
              />
            </div>
            <div className="space-y-4">
              <label className="block text-xs font-black text-gray-400 uppercase tracking-widest">Muqova URL</label>
              <input
                type="text"
                className="w-full px-5 py-4 rounded-xl bg-gray-50 border-none focus:ring-2 focus:ring-blue-600 font-medium"
                value={editingCourse.thumbnail}
                onChange={(e) => setEditingCourse({ ...editingCourse, thumbnail: e.target.value })}
              />
            </div>
            <div className="md:col-span-2 space-y-4">
              <label className="block text-xs font-black text-gray-400 uppercase tracking-widest">Ko'rinuvchanlik</label>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <MultiSelectDropdown
                    label="Tashkilotlar"
                    options={teachers.map(t => ({ id: t.uid, name: t.displayName || 'Anonim Tashkilot' }))}
                    selectedIds={editingCourse.organizationIds || []}
                    onChange={(id, checked) => {
                      const current = editingCourse.organizationIds || [];
                      const next = checked ? [...current, id] : current.filter(x => x !== id);
                      setEditingCourse({ ...editingCourse, organizationIds: next });
                    }}
                    placeholder="Barcha tashkilotlar"
                    theme="blue"
                  />
                </div>
                <div>
                  <MultiSelectDropdown
                    label="Yo'nalishlar"
                    options={departments}
                    selectedIds={editingCourse.departmentIds || []}
                    onChange={(id, checked) => {
                      const current = editingCourse.departmentIds || [];
                      const next = checked ? [...current, id] : current.filter(x => x !== id);
                      setEditingCourse({ 
                        ...editingCourse, 
                        departmentIds: next,
                        groupIds: (editingCourse.groupIds || []).filter(gid => {
                          const g = groups.find(x => x.id === gid);
                          return g && next.includes(g.departmentId);
                        })
                      });
                    }}
                    placeholder="Barcha yo'nalishlar"
                    theme="blue"
                  />
                </div>
                {editingCourse.departmentIds && editingCourse.departmentIds.length > 0 && (
                  <div>
                    <MultiSelectDropdown
                      label="Guruhlar"
                      options={groups.filter(g => editingCourse.departmentIds?.includes(g.departmentId))}
                      selectedIds={editingCourse.groupIds || []}
                      onChange={(id, checked) => {
                        const current = editingCourse.groupIds || [];
                        const next = checked ? [...current, id] : current.filter(x => x !== id);
                        setEditingCourse({ ...editingCourse, groupIds: next });
                      }}
                      placeholder="Barcha guruhlar"
                      theme="blue"
                    />
                  </div>
                )}
              </div>
            </div>

            <div className="md:col-span-2 space-y-4">
              <label className="block text-xs font-black text-gray-400 uppercase tracking-widest">Tavsif</label>
              <textarea
                rows={3}
                className="w-full px-5 py-4 rounded-xl bg-gray-50 border-none focus:ring-2 focus:ring-blue-600 font-medium leading-relaxed"
                value={editingCourse.description}
                onChange={(e) => setEditingCourse({ ...editingCourse, description: e.target.value })}
              />
            </div>
          </div>
          
          {/* Modules Section */}
          <div className="space-y-6 pt-6 border-t border-gray-100">
             <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold text-gray-900 flex items-center gap-2"><Layout className="h-5 w-5"/> Modullar va Kontent</h3>
                <span className="text-sm font-bold text-gray-400 bg-gray-100 px-3 py-1 rounded-full">Har bir modul uchun AI 5 ta test generatsiya qiladi. Yakuniyda 15 ta.</span>
             </div>
             
             {editingCourse.modules?.map((mod, idx) => (
                <div key={idx} className="bg-gray-50 rounded-2xl p-6 space-y-4 border border-gray-100 relative">
                   <div className="absolute top-4 right-4 bg-blue-100 text-blue-800 text-xs font-black px-3 py-1 rounded-full">
                      MODUL {idx + 1}
                   </div>
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                         <label className="block text-xs font-black text-gray-400 uppercase tracking-widest">Mavzu</label>
                         <input
                           type="text"
                           className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-600 font-bold"
                           value={mod.title}
                           onChange={(e) => updateModule(idx, 'title', e.target.value)}
                         />
                      </div>
                      <div className="space-y-2">
                         <label className="block text-xs font-black text-gray-400 uppercase tracking-widest flex justify-between">
                            <span>Video URL (YouTube embed)</span>
                         </label>
                         <input
                           type="text"
                           placeholder="https://www.youtube.com/embed/..."
                           className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-600 font-medium"
                           value={mod.videoUrl || ''}
                           onChange={(e) => updateModule(idx, 'videoUrl', e.target.value)}
                         />
                      </div>
                      <div className="md:col-span-2 space-y-2">
                         <label className="block text-xs font-black text-gray-400 uppercase tracking-widest">Matn/Ma'lumotlar (Shu asosida AI test yaratadi)</label>
                         <textarea
                           rows={3}
                           className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-600 font-medium text-sm"
                           value={mod.content}
                           onChange={(e) => updateModule(idx, 'content', e.target.value)}
                         />
                      </div>
                   </div>
                </div>
             ))}
          </div>

          <div className="pt-6 border-t border-gray-50 flex justify-end gap-4">
            <button
               onClick={() => setEditingCourse(null)}
               className="px-8 py-4 bg-gray-100 text-gray-600 rounded-xl font-bold hover:bg-gray-200 transition-all"
            >
              BEKOR QILISH
            </button>
            <button
               onClick={handleSave}
               disabled={loading}
               className="flex items-center gap-2 px-8 py-4 bg-blue-600 text-white rounded-xl font-black shadow-xl shadow-blue-100 hover:bg-blue-700 transition-all"
            >
              {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Save className="h-5 w-5" />}
              SAQLASH
            </button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
        {courses
          .filter(c => activeTab === 'base' ? (!c.creatorRole || c.creatorRole === 'admin') : (c.creatorRole === 'teacher'))
          .map((course) => (
          <div key={course.id} className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden flex flex-col group hover:shadow-2xl transition-all">
            <div className="relative h-48 overflow-hidden">
               <img src={course.thumbnail || null} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
               <div className="absolute top-4 right-4 flex gap-2">
                 <button 
                   onClick={() => setEditingCourse(course)}
                   className="p-2.5 bg-white/90 backdrop-blur text-blue-600 rounded-xl shadow-lg hover:bg-white transition-colors"
                 >
                   <Edit className="h-4 w-4" />
                 </button>
                 <button 
                  onClick={() => handleDelete(course.id)}
                  className="p-2.5 bg-white/90 backdrop-blur text-red-600 rounded-xl shadow-lg hover:bg-white transition-colors"
                 >
                   <Trash2 className="h-4 w-4" />
                 </button>
               </div>
            </div>
            <div className="p-8 space-y-4 flex flex-col flex-1">
               <h3 className="text-xl font-black text-gray-900">{course.title}</h3>
               {course.creatorName && (
                  <p className="text-xs font-semibold text-blue-600 bg-blue-50 w-max px-2 py-1 rounded">Muallif: {course.creatorName}</p>
               )}
               <div className="flex items-center gap-4 text-xs font-bold text-gray-400 uppercase tracking-widest mt-auto mb-2">
                  <div className="flex items-center gap-1.5 bg-gray-50 px-2 py-1 rounded-lg">
                    <Layout className="h-4 w-4" />
                    {course.modules?.length || 0} Modul
                  </div>
               </div>
               <p className="text-gray-500 text-sm line-clamp-2 leading-relaxed">
                  {course.description}
               </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
