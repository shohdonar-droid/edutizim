import { useState, useEffect } from 'react';
import { db } from '../../lib/firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { SiteContent } from '../../types';
import { Save, Loader2, Info, Image as ImageIcon, Type, Badge, FileText, Plus, Trash2, Globe } from 'lucide-react';

export default function AdminInfo() {
  const [content, setContent] = useState<SiteContent | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    async function load() {
      const snap = await getDoc(doc(db, 'siteContent', 'main'));
      if (snap.exists()) {
        const data = snap.data() as SiteContent;
        // Migration/Default for new fields
        if (!data.hero.rightBadge) data.hero.rightBadge = "Yangilik";
        if (!data.hero.detailFiles) data.hero.detailFiles = [];
        setContent(data);
      } else {
        setContent({
          hero: { rightImage: '', rightText: '', rightBadge: 'Yangilik', detailHtml: '', detailFiles: [] },
          banners: [],
          footer: { top: '', bottom: '' }
        });
      }
    }
    load();
  }, []);

  const handleUpdate = async () => {
    if (!content) return;
    setLoading(true);
    try {
      await setDoc(doc(db, 'siteContent', 'main'), { hero: content.hero }, { merge: true });
      alert('Ma\'lumotlar saqlandi!');
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  const addFile = () => {
    if (!content) return;
    const newFiles = [...(content.hero.detailFiles || []), { name: '', url: '', type: 'PDF' }];
    setContent({ ...content, hero: { ...content.hero, detailFiles: newFiles } });
  };

  const removeFile = (idx: number) => {
    if (!content || !content.hero.detailFiles) return;
    const newFiles = content.hero.detailFiles.filter((_, i) => i !== idx);
    setContent({ ...content, hero: { ...content.hero, detailFiles: newFiles } });
  };

  const updateFile = (idx: number, field: string, val: string) => {
    if (!content || !content.hero.detailFiles) return;
    const newFiles = [...content.hero.detailFiles];
    newFiles[idx] = { ...newFiles[idx], [field]: val };
    setContent({ ...content, hero: { ...content.hero, detailFiles: newFiles } });
  };

  if (!content) return null;

  return (
    <div className="space-y-10 pb-20">
      <header className="flex justify-between items-center">
        <div>
          <h1 className="text-4xl font-black text-gray-900 tracking-tight">Info tahrirlash</h1>
          <p className="text-gray-500 mt-2 text-lg">Asosiy sahifadagi yangiliklar va batafsil sahifa mazmuni.</p>
        </div>
        <button
          onClick={handleUpdate}
          disabled={loading}
          className="flex items-center gap-2 px-8 py-4 bg-blue-600 text-white rounded-2xl font-black shadow-2xl shadow-blue-200 hover:bg-blue-700 transition-all disabled:opacity-50"
        >
          {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Save className="h-5 w-5" />}
          SAQLASH
        </button>
      </header>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-10">
        {/* News Card Section */}
        <div className="space-y-8">
           <div className="bg-white rounded-3xl p-10 border border-gray-100 shadow-sm space-y-8">
             <h3 className="text-xl font-black text-gray-900 flex items-center gap-2">
               <ImageIcon className="h-5 w-5 text-blue-600" />
               Yangilik kartasi
             </h3>
             
             <div className="space-y-4">
                <label className="text-xs font-black text-gray-400 uppercase tracking-widest flex items-center gap-2">
                  <ImageIcon className="h-4 w-4" /> Rasm (Yuklash)
                </label>
                <input
                  type="file"
                  accept="image/*"
                  className="w-full px-5 py-3 rounded-xl bg-gray-50 border-none focus:ring-2 focus:ring-blue-600 font-medium file:cursor-pointer file:bg-blue-600 file:text-white file:border-0 file:py-2 file:px-4 file:rounded-xl file:mr-4 file:font-semibold hover:file:bg-blue-700"
                  onChange={(e) => {
                     const file = e.target.files?.[0];
                     if(!file) return;
                     const reader = new FileReader();
                     reader.onloadend = () => {
                       setContent({ ...content, hero: { ...content.hero, rightImage: reader.result as string } });
                     };
                     reader.readAsDataURL(file);
                  }}
                />
             </div>

             <div className="space-y-4">
                <label className="text-xs font-black text-gray-400 uppercase tracking-widest flex items-center gap-2">
                  <Globe className="h-4 w-4" /> Ko'k belgi matni
                </label>
                <input
                  type="text"
                  className="w-full px-5 py-4 rounded-xl bg-gray-50 border-none focus:ring-2 focus:ring-blue-600 font-medium"
                  placeholder="Yangilik, Elon, etc."
                  value={content.hero.rightBadge || ''}
                  onChange={(e) => setContent({ ...content, hero: { ...content.hero, rightBadge: e.target.value } })}
                />
             </div>

             <div className="space-y-4">
                <label className="text-xs font-black text-gray-400 uppercase tracking-widest flex items-center gap-2">
                  <Type className="h-4 w-4" /> Qisqa tavsif (Bosh sahifa uchun)
                </label>
                <textarea
                  rows={3}
                  className="w-full px-5 py-4 rounded-xl bg-gray-50 border-none focus:ring-2 focus:ring-blue-600 font-medium"
                  value={content.hero.rightText}
                  onChange={(e) => setContent({ ...content, hero: { ...content.hero, rightText: e.target.value } })}
                />
             </div>
           </div>

           {/* Files Section */}
           <div className="bg-white rounded-3xl p-10 border border-gray-100 shadow-sm space-y-8">
              <div className="flex justify-between items-center">
                 <h3 className="text-xl font-black text-gray-900 flex items-center gap-2">
                   <FileText className="h-5 w-5 text-blue-600" />
                   Yuklanadigan fayllar (PDF, PPT, PPTX)
                 </h3>
                 <button onClick={addFile} className="p-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors">
                    <Plus className="h-5 w-5" />
                 </button>
              </div>

              <div className="space-y-4">
                 {(content.hero.detailFiles || []).map((file, idx) => (
                   <div key={idx} className="p-6 bg-gray-50 rounded-2xl border border-gray-100 space-y-4">
                      <div className="flex justify-between gap-4">
                         <input 
                           type="text"
                           placeholder="Fayl nomi"
                           className="flex-1 px-4 py-2 rounded-lg border-none bg-white font-bold text-sm"
                           value={file.name}
                           onChange={(e) => updateFile(idx, 'name', e.target.value)}
                         />
                         <select 
                           className="px-4 py-2 rounded-lg border-none bg-white font-bold text-sm"
                           value={file.type}
                           onChange={(e) => updateFile(idx, 'type', e.target.value)}
                         >
                            <option value="PDF">PDF</option>
                            <option value="PPT">PPT</option>
                            <option value="PPTX">PPTX</option>
                            <option value="DOCX">DOCX</option>
                         </select>
                         <button onClick={() => removeFile(idx)} className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors">
                            <Trash2 className="h-5 w-5" />
                         </button>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-gray-400 uppercase">Fayl yuklash</label>
                          <input 
                            type="file"
                            onChange={(e) => {
                              const f = e.target.files?.[0];
                              if (!f) return;
                              const reader = new FileReader();
                              reader.onloadend = () => updateFile(idx, 'url', reader.result as string);
                              reader.readAsDataURL(f);
                            }}
                            className="w-full text-xs file:bg-blue-50 file:text-blue-600 file:border-0 file:rounded-lg file:px-3 file:py-1 file:font-bold"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-gray-400 uppercase">Fayl URL (yoki avtomatik)</label>
                          <input 
                             type="text"
                             placeholder="Fayl URL manzili"
                             className="w-full px-4 py-2 rounded-lg border-none bg-white font-medium text-xs font-mono"
                             value={file.url}
                             onChange={(e) => updateFile(idx, 'url', e.target.value)}
                          />
                        </div>
                      </div>
                      {file.url && (
                        <p className="text-[10px] text-green-600 font-bold truncate">✓ Fayl tayyor (Base64/URL)</p>
                      )}
                   </div>
                 ))}
                 {(content.hero.detailFiles || []).length === 0 && (
                   <p className="text-gray-400 text-sm font-medium italic">Fayllar qo'shilmagan.</p>
                 )}
              </div>
           </div>
        </div>

        {/* Detailed Page Content */}
        <div className="space-y-8">
           <div className="bg-white rounded-3xl p-10 border border-gray-100 shadow-sm space-y-8">
             <h3 className="text-xl font-black text-gray-900 flex items-center gap-2">
               <Globe className="h-5 w-5 text-blue-600" />
               Batafsil ma'lumot (Sahifa mazmuni)
             </h3>
             <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-black text-gray-400 uppercase tracking-widest">Sahifa HTML mazmuni</label>
                  <button 
                    onClick={() => {
                      const input = document.createElement('input');
                      input.type = 'file';
                      input.accept = 'image/*';
                      input.onchange = (e: any) => {
                        const file = e.target.files?.[0];
                        if (!file) return;
                        const reader = new FileReader();
                        reader.onloadend = () => {
                          const imgTag = `<img src="${reader.result}" alt="Image" style="max-width:100%; border-radius:12px; margin:20px 0;" />`;
                          setContent({ ...content, hero: { ...content.hero, detailHtml: (content.hero.detailHtml || '') + imgTag } });
                        };
                        reader.readAsDataURL(file);
                      };
                      input.click();
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-green-50 text-green-600 rounded-lg text-xs font-black hover:bg-green-600 hover:text-white transition-all shadow-sm"
                  >
                    <ImageIcon className="h-3.5 w-3.5" /> RASM QO'SHISH
                  </button>
                </div>
                <textarea
                  rows={20}
                  className="w-full px-5 py-4 rounded-xl bg-gray-50 border-none focus:ring-2 focus:ring-blue-600 font-mono text-sm leading-relaxed"
                  placeholder="<p>Bu erga batafsil ma'lumotni HTML ko'rinishida yozing...</p>"
                  value={content.hero.detailHtml || ''}
                  onChange={(e) => setContent({ ...content, hero: { ...content.hero, detailHtml: e.target.value } })}
                />
                <p className="text-[10px] text-gray-400 font-medium italic">* HTML teglari va inline uslublar qo'llab-quvvatlanadi. Rasm qo'shish uchun yuqoridagi tugmadan foydalaning.</p>
             </div>
           </div>

           {/* Preview Card */}
           <div className="space-y-4">
              <label className="text-xs font-black text-gray-400 uppercase tracking-widest">Karta ko'rinishi (Preview)</label>
              <div className="bg-white rounded-3xl border-4 border-gray-100 shadow-2xl overflow-hidden flex flex-col h-[500px]">
                <img 
                  src={content.hero.rightImage || null} 
                  alt="Preview" 
                  className="h-[65%] w-full object-cover"
                />
                <div className="p-8 flex-1 flex flex-col justify-center bg-white relative z-10 -mt-6 rounded-t-3xl shadow-[0_-10px_30px_rgba(0,0,0,0.05)]">
                  <span className="text-xs font-black text-blue-600 uppercase tracking-widest mb-2 block">{content.hero.rightBadge || 'Yangilik'}</span>
                  <p className="text-xl font-bold text-gray-900 leading-tight">
                    {content.hero.rightText}
                  </p>
                  <div className="mt-6 flex items-center gap-2 text-gray-400 font-bold text-xs uppercase tracking-widest">
                    Batafsil ma'lumot <div className="w-8 h-[2px] bg-gray-200" />
                  </div>
                </div>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
}

