import React, { useState, useEffect } from 'react';
import { db } from '../../lib/firebase';
import { collection, getDocs, doc, updateDoc, setDoc, query, where, onSnapshot, deleteDoc, serverTimestamp } from 'firebase/firestore';
import { UserProfile, Department, Group } from '../../types';
import { Search, Download, Trash2, Key, Filter, Edit, Plus, Users, LayoutDashboard, Loader2, Save, X } from 'lucide-react';
import firebaseConfig from '../../../firebase-applet-config.json';
import { useAuth } from '../../hooks/useAuth';

export default function AdminUsers() {
  const { user } = useAuth();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [teachers, setTeachers] = useState<UserProfile[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterDept, setFilterDept] = useState('');
  const [filterGrp, setFilterGrp] = useState('');
  const [filterOrg, setFilterOrg] = useState('');
  const [activeTab, setActiveTab] = useState<'students' | 'teachers'>('teachers');

  // Teacher Creation/Edit
  const [editingTeacher, setEditingTeacher] = useState<Partial<UserProfile> | null>(null);
  const [teacherSaving, setTeacherSaving] = useState(false);

  useEffect(() => {
    const unsubDepts = onSnapshot(collection(db, 'departments'), (snap) => {
      setDepartments(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Department)));
    });
    const unsubGroups = onSnapshot(collection(db, 'groups'), (snap) => {
      setGroups(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Group)));
    });

    const unsubStudents = onSnapshot(query(collection(db, 'users'), where('role', '==', 'student')), (snap) => {
      const dbUsers = snap.docs.map(doc => ({ ...doc.data() } as UserProfile));
      dbUsers.sort((a, b) => (a.displayName || '').localeCompare(b.displayName || '', 'uz-UZ'));
      setUsers(dbUsers);
    });

    const unsubTeachers = onSnapshot(query(collection(db, 'users'), where('role', '==', 'teacher')), (snap) => {
      const dbUsers = snap.docs.map(doc => ({ uid: doc.id, ...doc.data() } as UserProfile));
      dbUsers.sort((a, b) => (a.displayName || '').localeCompare(b.displayName || '', 'uz-UZ'));
      setTeachers(dbUsers);
      setLoading(false);
    });

    return () => { unsubDepts(); unsubGroups(); unsubStudents(); unsubTeachers(); };
  }, []);

  const deleteSingleUser = async (uid: string) => {
    if (!confirm("Haqiqatan ham o'chirmoqchimisiz? Rozi bo'lsangiz, barcha ma'lumotlar o'chiriladi!")) return;
    try {
      await deleteDoc(doc(db, 'users', uid));

      const eQ = query(collection(db, 'enrollments'), where("userId", "==", uid));
      const eSnap = await getDocs(eQ);
      for (const d of eSnap.docs) {
        await deleteDoc(doc(db, 'enrollments', d.id));
      }

      const rQ = query(collection(db, 'testResults'), where("userId", "==", uid));
      const rSnap = await getDocs(rQ);
      for (const d of rSnap.docs) {
        await deleteDoc(doc(db, 'testResults', d.id));
      }
      
    } catch (error) {
      console.error(error);
      alert("O'chirishda xatolik yuz berdi");
    }
  };

  const saveTeacher = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTeacher?.displayName || !editingTeacher?.login || !editingTeacher?.password) {
       alert("Barcha maydonlarni to'ldiring."); return;
    }
    if (editingTeacher.password.length < 6) {
       alert("Parol kamida 6 ta belgidan iborat bo'lishi kerak."); return;
    }
    setTeacherSaving(true);
    let uid = editingTeacher.uid;
    try {
      if (uid) {
         // Update existing
         await updateDoc(doc(db, 'users', uid), {
            displayName: editingTeacher.displayName,
            phone: editingTeacher.phone || '',
            login: editingTeacher.login.trim(),
            password: editingTeacher.password,
            ball: Number(editingTeacher.ball) || 0,
            aiTestLimit: Number(editingTeacher.aiTestLimit) || 20
         });
      } else {
         // Check if login already exists
         const q = query(collection(db, 'users'), where('login', '==', editingTeacher.login.trim()));
         const qSnap = await getDocs(q);
         if (!qSnap.empty) {
            alert("Xato: Bu login allaqachon band! Boshqa login tanlang.");
            setTeacherSaving(false);
            return;
         }

         // Create user via REST API to prevent logging out admin
         const email = `t_${Date.now()}@teacher.uz`;
         const response = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=${firebaseConfig.apiKey}`, {
           method: 'POST',
           headers: { 'Content-Type': 'application/json' },
           body: JSON.stringify({
             email,
             password: editingTeacher.password,
             returnSecureToken: false
           })
         });

         if (!response.ok) {
           const errData = await response.json();
           throw new Error(errData.error.message || "Foydalanuvchi yaratishda xatolik");
         }
         const data = await response.json();
         uid = data.localId;

         await setDoc(doc(db, 'users', uid), {
             uid: uid,
             displayName: editingTeacher.displayName,
             phone: editingTeacher.phone || '',
             login: editingTeacher.login.trim(),
             password: editingTeacher.password,
             ball: Number(editingTeacher.ball) || 0,
             role: 'teacher',
             email: email,
             createdAt: serverTimestamp()
         });
      }
      setEditingTeacher(null);
    } catch (err: any) {
      console.error(err);
      if (err.code === 'auth/email-already-in-use') {
        alert("Xato: Bu login allaqachon band! Boshqa login tanlang.");
      } else {
        alert("Xato: " + err.message);
      }
    } finally {
      setTeacherSaving(false);
    }
  };

  const impersonateTeacher = (uid: string) => {
    localStorage.setItem('impersonateUserId', uid);
    window.location.href = '/teacher';
  };

  const exportToCSV = () => {
    const headers = ['№', 'Tashkilot', 'Foydalanuvchi', 'Tel raqami', "Yo'nalish", 'Guruh', 'Login'];
    const csvRows = [headers.join('\t')];
    filteredUsers.forEach((u, i) => {
      const orgName = teachers.find(t => t.uid === u.teacherId)?.displayName || '-';
      const row = [i + 1, orgName, u.displayName || '', u.phone || '', u.departmentName || '', u.groupName || '', u.login || ''].map(e => `"${String(e).replace(/"/g, '""')}"`);
      csvRows.push(row.join('\t'));
    });
    const bom = new Uint8Array([0xEF, 0xBB, 0xBF]); // UTF-8 BOM
    const csvData = new Blob([bom, csvRows.join('\n')], { type: 'application/vnd.ms-excel;charset=utf-8' });
    const csvUrl = window.URL.createObjectURL(csvData);
    const hiddenElement = document.createElement('a');
    hiddenElement.href = csvUrl;
    hiddenElement.target = '_blank';
    hiddenElement.download = 'talabalar_royxati.xls';
    hiddenElement.click();
  };

  const exportTeachersCSV = () => {
    const headers = ['№', 'Tashkilot nomi', 'Tel raqam', 'Login', 'Parol', 'Ball'];
    const csvRows = [headers.join('\t')];
    filteredTeachers.forEach((t, i) => {
      const row = [i + 1, t.displayName || '', t.phone || '', t.login || '', t.password || '', t.ball || 0].map(e => `"${String(e).replace(/"/g, '""')}"`);
      csvRows.push(row.join('\t'));
    });
    const bom = new Uint8Array([0xEF, 0xBB, 0xBF]); // UTF-8 BOM
    const csvData = new Blob([bom, csvRows.join('\n')], { type: 'application/vnd.ms-excel;charset=utf-8' });
    const csvUrl = window.URL.createObjectURL(csvData);
    const hiddenElement = document.createElement('a');
    hiddenElement.href = csvUrl;
    hiddenElement.target = '_blank';
    hiddenElement.download = 'tashkilotlar_royxati.xls';
    hiddenElement.click();
  };

  let filteredUsers = users.filter(u => 
    (u.displayName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (u.login && u.login.toLowerCase().includes(searchTerm.toLowerCase()))
  );
  if (filterDept) filteredUsers = filteredUsers.filter(u => u.departmentId === filterDept);
  if (filterGrp) filteredUsers = filteredUsers.filter(u => u.groupId === filterGrp);
  if (filterOrg) filteredUsers = filteredUsers.filter(u => u.teacherId === filterOrg);
  
  const availableGroups = groups.filter(g => g.departmentId === filterDept);

  let filteredTeachers = teachers.filter(u => 
    (u.displayName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (u.login && u.login.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  if (loading) return <div className="text-gray-500 font-medium p-10">Yuklanmoqda...</div>;

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 pb-10">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h1 className="text-4xl font-black text-gray-900 tracking-tight">Foydalanuvchilar</h1>
          <p className="text-gray-500 mt-2 text-lg">Tashkilotlar va Talabalar boshqaruvi.</p>
        </div>
        <div className="flex bg-white rounded-2xl p-1.5 border border-gray-100 shadow-sm">
           <button
            onClick={() => setActiveTab('teachers')}
            className={`px-6 py-3 rounded-xl font-bold transition-all ${activeTab === 'teachers' ? 'bg-blue-600 text-white shadow' : 'text-gray-400 hover:text-gray-600'}`}
          >
            Tashkilotlar
          </button>
          <button
            onClick={() => setActiveTab('students')}
            className={`px-6 py-3 rounded-xl font-bold transition-all ${activeTab === 'students' ? 'bg-blue-600 text-white shadow' : 'text-gray-400 hover:text-gray-600'}`}
          >
            Talabalar
          </button>
        </div>
      </header>

      {activeTab === 'teachers' && (
        <div className="space-y-6">
           {editingTeacher ? (
              <div className="bg-white rounded-3xl p-8 border border-gray-100 shadow-xl max-w-3xl">
                 <div className="flex justify-between items-center mb-6">
                    <h2 className="text-2xl font-black text-gray-900">{editingTeacher.uid ? "Tashkilotni tahrirlash" : "Yangi tashkilot"}</h2>
                    <button onClick={() => setEditingTeacher(null)} className="text-gray-400 hover:bg-gray-100 p-2 rounded-lg"><X /></button>
                 </div>
                 <form onSubmit={saveTeacher} className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                       <label className="text-sm font-bold text-gray-700">Tashkilot nomi</label>
                       <input type="text" required className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl" value={editingTeacher.displayName || ''} onChange={e => setEditingTeacher({...editingTeacher, displayName: e.target.value})} />
                    </div>
                    <div className="space-y-2">
                       <label className="text-sm font-bold text-gray-700">Tel raqam</label>
                       <input type="text" className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl" value={editingTeacher.phone || ''} onChange={e => setEditingTeacher({...editingTeacher, phone: e.target.value})} />
                    </div>
                    <div className="space-y-2">
                       <label className="text-sm font-bold text-gray-700">Login (Kirish u-n)</label>
                       <input type="text" required className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl" value={editingTeacher.login || ''} onChange={e => setEditingTeacher({...editingTeacher, login: e.target.value})} disabled={!!editingTeacher.uid} />
                       {editingTeacher.uid && <p className="text-xs text-orange-500">Loginni o'zgartirib bo'lmaydi</p>}
                    </div>
                    <div className="space-y-2">
                       <label className="text-sm font-bold text-gray-700">Parol (123456...)</label>
                       <input type="text" required className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl" value={editingTeacher.password || ''} onChange={e => setEditingTeacher({...editingTeacher, password: e.target.value})} />
                    </div>
                    <div className="space-y-2">
                       <label className="text-sm font-bold text-gray-700">Test generatsiyasi limiti</label>
                       <input type="number" className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl" value={editingTeacher.aiTestLimit || 20} onChange={e => setEditingTeacher({...editingTeacher, aiTestLimit: parseInt(e.target.value)})} />
                    </div>
                    <div className="md:col-span-2 flex justify-end gap-2 mt-4 pt-4 border-t">
                       <button type="submit" disabled={teacherSaving} className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-xl font-bold shadow hover:bg-blue-700 disabled:opacity-50">
                          {teacherSaving ? <Loader2 className="animate-spin w-5 h-5"/> : <Save className="w-5 h-5" />} SAQLASH
                       </button>
                    </div>
                 </form>
              </div>
           ) : (
              <div className="flex flex-col md:flex-row justify-between items-center gap-4 bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
                 <div className="relative w-full md:w-96 flex-shrink-0">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <input type="text" className="w-full pl-12 pr-6 py-3 rounded-xl bg-gray-50 border border-gray-100 placeholder:text-gray-400" placeholder="Qidirish..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
                 </div>
                 <div className="flex gap-2 w-full md:w-auto">
                    <button onClick={exportTeachersCSV} className="flex-1 md:flex-none flex items-center justify-center gap-2 px-6 py-3 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 transition-all">
                       <Download className="w-5 h-5" /> YUKLAB OLISH
                    </button>
                    <button onClick={() => setEditingTeacher({ displayName: '', login: '', password: '', phone: '', ball: 0 })} className="flex-1 md:flex-none flex items-center justify-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-xl font-black hover:bg-blue-700 shadow-lg shadow-blue-100 transition-all">
                       <Plus className="w-5 h-5" /> YANGI TASHKILOT
                    </button>
                 </div>
              </div>
           )}

           {!editingTeacher && (
              <div className="bg-white rounded-3xl border border-gray-100 shadow-xl overflow-hidden">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="bg-gray-50/50 border-b border-gray-50">
                      <th className="px-6 py-4 text-left text-xs font-black text-gray-400 uppercase">№</th>
                      <th className="px-6 py-4 text-left text-xs font-black text-gray-400 uppercase">Tashkilot nomi</th>
                      <th className="px-6 py-4 text-left text-xs font-black text-gray-400 uppercase">Tel raqam</th>
                      <th className="px-6 py-4 text-left text-xs font-black text-gray-400 uppercase">Login</th>
                      <th className="px-6 py-4 text-left text-xs font-black text-gray-400 uppercase">Parol</th>
                      <th className="px-6 py-4 text-right text-xs font-black text-gray-400 uppercase">Amallar</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {filteredTeachers.map((t, i) => (
                      <tr key={t.uid} className="hover:bg-gray-50/30 group transition">
                        <td className="px-6 py-4 font-bold text-gray-400">{i+1}</td>
                        <td className="px-6 py-4">
                           <button onClick={() => impersonateTeacher(t.uid)} className="font-black text-blue-600 hover:underline inline-flex items-center gap-1" title="Teacher profiliga kirish">
                              <LayoutDashboard className="w-4 h-4"/> {t.displayName}
                           </button>
                        </td>
                        <td className="px-6 py-4 text-sm font-medium text-gray-500">{t.phone || '-'}</td>
                        <td className="px-6 py-4 text-sm font-bold text-gray-500">{t.login || '-'}</td>
                        <td className="px-6 py-4 text-sm font-mono text-gray-400">{t.password || '-'}</td>
                        <td className="px-6 py-4 text-right">
                           <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                              <button onClick={() => setEditingTeacher(t)} className="p-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100">
                                 <Edit className="w-4 h-4" />
                              </button>
                              <button onClick={() => deleteSingleUser(t.uid)} className="p-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100">
                                 <Trash2 className="w-4 h-4" />
                              </button>
                           </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
           )}
        </div>
      )}

      {activeTab === 'students' && (
        <div className="space-y-6">
           <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm flex flex-col md:flex-row gap-4 items-center">
             <div className="relative w-full md:w-80 flex-shrink-0">
               <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
               <input type="text" className="w-full pl-12 pr-6 py-3 rounded-xl bg-gray-50 border border-gray-100 focus:ring-2 focus:ring-blue-600" placeholder="Qidirish..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
             </div>
             <div className="flex flex-wrap items-center gap-2 w-full md:w-auto flex-1">
                <select value={filterOrg} onChange={e => { setFilterOrg(e.target.value); setFilterDept(''); setFilterGrp(''); }} className="px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl text-sm font-bold text-blue-600 w-full md:w-auto outline-none focus:ring-2 focus:ring-blue-600">
                  <option value="">Barcha tashkilotlar</option>
                  {teachers.map(t => <option key={t.uid} value={t.uid}>{t.displayName}</option>)}
                </select>
                <select value={filterDept} onChange={e => { setFilterDept(e.target.value); setFilterGrp(''); }} className="px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl text-sm font-medium w-full md:w-auto outline-none focus:ring-2 focus:ring-blue-600">
                  <option value="">Barcha yo'nalishlar</option>
                  {departments.filter(d => !filterOrg || d.creatorId === filterOrg).map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                </select>
                <select value={filterGrp} onChange={e => setFilterGrp(e.target.value)} disabled={!filterDept} className="px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl text-sm font-medium w-full md:w-auto disabled:opacity-50 outline-none focus:ring-2 focus:ring-blue-600">
                  <option value="">Barcha guruhlar</option>
                  {availableGroups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
                </select>
             </div>
             <button onClick={exportToCSV} className="flex items-center gap-2 px-6 py-3 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 whitespace-nowrap transition-all shadow-lg shadow-green-100">
                <Download className="w-5 h-5" /> YUKLAB OLISH
             </button>
           </div>

           <div className="bg-white rounded-3xl border border-gray-100 shadow-xl overflow-hidden">
             <div className="overflow-x-auto">
               <table className="w-full border-collapse">
                 <thead>
                   <tr className="bg-gray-50/50 border-b border-gray-50">
                     <th className="px-6 py-5 text-left text-xs font-black text-gray-400 uppercase whitespace-nowrap">№</th>
                     <th className="px-6 py-5 text-left text-xs font-black text-gray-400 uppercase">Tashkilot</th>
                     <th className="px-6 py-5 text-left text-xs font-black text-gray-400 uppercase whitespace-nowrap">FISH (Talaba)</th>
                     <th className="px-6 py-5 text-left text-xs font-black text-gray-400 uppercase whitespace-nowrap">Tel raqami</th>
                     <th className="px-6 py-5 text-center text-xs font-black text-gray-400 uppercase">Yo'nalish</th>
                     <th className="px-6 py-5 text-center text-xs font-black text-gray-400 uppercase">Guruh</th>
                     <th className="px-6 py-5 text-center text-xs font-black text-gray-400 uppercase">Login</th>
                     <th className="px-6 py-5 text-right text-xs font-black text-gray-400 uppercase whitespace-nowrap">Amallar</th>
                   </tr>
                 </thead>
                 <tbody className="divide-y divide-gray-50">
                   {filteredUsers.map((u, i) => {
                     const org = teachers.find(t => t.uid === u.teacherId);
                     return (
                      <tr key={u.uid} className="hover:bg-gray-50/30 group">
                        <td className="px-6 py-4 font-bold text-gray-400 whitespace-nowrap">{i + 1}</td>
                        <td className="px-6 py-4">
                          <span className="bg-blue-50 text-blue-700 px-2.5 py-1.5 rounded-lg text-xs font-black uppercase tracking-tight">
                            {org?.displayName || '-'}
                          </span>
                        </td>
                        <td className="px-6 py-4 font-black uppercase text-sm">{u.displayName}</td>
                        <td className="px-6 py-4 text-sm font-medium text-gray-500 whitespace-nowrap">{u.phone || '-'}</td>
                        <td className="px-6 py-4 text-sm font-medium text-gray-500 text-center uppercase">{u.departmentName || '-'}</td>
                        <td className="px-6 py-4 text-sm font-black text-gray-500 text-center uppercase">{u.groupName || '-'}</td>
                        <td className="px-6 py-4 text-sm font-bold text-indigo-600 bg-indigo-50/50 text-center">{u.login || '-'}</td>
                        <td className="px-6 py-4 text-right">
                            <button onClick={() => deleteSingleUser(u.uid)} className="p-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition shadow-sm opacity-0 group-hover:opacity-100">
                              <Trash2 className="w-4 h-4" />
                            </button>
                        </td>
                      </tr>
                     );
                   })}
                 </tbody>
               </table>
               {filteredUsers.length === 0 && (
                 <div className="p-20 text-center text-gray-400 font-bold italic opacity-30">Hech qanday talaba topilmadi.</div>
               )}
             </div>
           </div>
        </div>
      )}
    </div>
  );
}
