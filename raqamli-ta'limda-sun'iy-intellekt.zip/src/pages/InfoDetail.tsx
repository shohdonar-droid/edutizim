import { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { doc, getDoc } from 'firebase/firestore';
import { SiteContent } from '../types';
import { ArrowLeft, FileText, Download, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';

export default function InfoDetail() {
  const [content, setContent] = useState<SiteContent['hero'] | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const snap = await getDoc(doc(db, 'siteContent', 'main'));
      if (snap.exists()) {
        const data = snap.data() as SiteContent;
        setContent(data.hero);
      }
      setLoading(false);
    }
    load();
  }, []);

  if (loading) {
     return (
       <div className="min-h-screen flex items-center justify-center">
         <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
       </div>
     );
  }

  if (!content) return null;

  return (
    <div className="max-w-4xl mx-auto px-4 py-20">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-12"
      >
        <Link to="/" className="inline-flex items-center gap-2 text-gray-500 hover:text-blue-600 font-bold transition-colors">
          <ArrowLeft className="h-5 w-5" /> Bosh sahifaga qaytish
        </Link>

        <header className="space-y-6">
           <span className="px-4 py-1.5 bg-blue-50 text-blue-600 rounded-lg text-xs font-black uppercase tracking-widest">
             {content.rightBadge || "Yangilik"}
           </span>
           <h1 className="text-4xl md:text-5xl font-black text-gray-900 leading-tight">
             {content.rightText}
           </h1>
        </header>

        {content.rightImage && (
          <div className="mac-window overflow-hidden rounded-3xl">
            <img src={content.rightImage || null} alt="Cover" className="w-full h-auto max-h-[600px] object-cover" />
          </div>
        )}

        <div className="prose prose-lg max-w-none text-gray-700 font-medium leading-relaxed">
           {content.detailHtml ? (
             <div dangerouslySetInnerHTML={{ __html: content.detailHtml }} />
           ) : (
             <p className="italic text-gray-400">Ma'lumotlar mavjud emas.</p>
           )}
        </div>

        {content.detailFiles && content.detailFiles.length > 0 && (
          <div className="space-y-6 pt-12 border-t border-gray-100">
            <h3 className="text-2xl font-black text-gray-900">Yuklab olinadigan fayllar</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
               {content.detailFiles.map((file, idx) => (
                 <a 
                   key={idx}
                   href={file.url}
                   target="_blank"
                   rel="noopener noreferrer"
                   className="p-6 bg-gray-50 rounded-2xl border border-gray-100 flex items-center gap-4 hover:bg-white hover:shadow-xl hover:shadow-gray-100 transition-all group"
                 >
                   <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-blue-600 group-hover:scale-110 transition-transform">
                      <FileText className="h-6 w-6" />
                   </div>
                   <div className="flex-1 min-w-0">
                      <p className="font-bold text-gray-900 truncate">{file.name}</p>
                      <p className="text-xs text-gray-500 uppercase font-black">{file.type}</p>
                   </div>
                   <Download className="h-5 w-5 text-gray-400 group-hover:text-blue-600" />
                 </a>
               ))}
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
}
