import { useState, useEffect } from 'react';
import { db } from '../../lib/firebase';
import { collection, getDocs, doc, deleteDoc, query, where, onSnapshot } from 'firebase/firestore';
import { UserProfile, Department, Group } from '../../types';
import { Search, Trash2, Filter } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';

export default function TeacherStudents() {
  const { user } = useAuth();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [teacherDepartments, setTeacherDepartments] = useState<Department[]>([]);
  const [teacherGroups, setTeacherGroups] = useState<Group[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterDeptId, setFilterDeptId] = useState<string>('');
  const [filterGroupId, setFilterGroupId] = useState<string>('');

  useEffect(() => {
    if (!user) return;

    const load = async () => {
      try {
        // Teacher's departments
        const deptSnap = await getDocs(query(collection(db, 'departments'), where('creatorId', '==', user.uid)));
        const depts = deptSnap.docs.map(d => ({ id: d.id, ...d.data() } as Department));
        setTeacherDepartments(depts);
        
        // Teacher's groups
        const groupSnap = await getDocs(query(collection(db, 'groups'), where('creatorId', '==', user.uid)));
        const grps = groupSnap.docs.map(g => ({ id: g.id, ...g.data() } as Group));
        setTeacherGroups(grps);

        const deptIds = depts.map(d => d.id);

        if (deptIds.length === 0) {
           setUsers([]);
           setLoading(false);
           return;
        }

        // Students in these departments
        // NOTE: Firestore requires the 'in' array to be <= 30 elements
        const q = query(collection(db, 'users'), where('role', '==', 'student'), where('departmentId', 'in', deptIds.slice(0, 30)));
        const unsub = onSnapshot(q, (snap) => {
          const dbUsers = snap.docs.map(doc => ({ ...doc.data() } as UserProfile));
          dbUsers.sort((a, b) => a.displayName.localeCompare(b.displayName, 'uz-UZ'));
          setUsers(dbUsers);
          setLoading(false);
        });

        return () => unsub();
      } catch (err) {
        console.error(err);
        setLoading(false);
      }
    };
    load();
  }, [user]);

  const deleteSingleUser = async (uid: string) => {
    if (!confirm("Haqiqatan ham o'chirmoqchimisiz?")) return;
    try {
      await deleteDoc(doc(db, 'users', uid));
    } catch (error) {
      console.error(error);
      alert("O'chirishda xatolik yuz berdi");
    }
  };

  const filteredUsers = users.filter(u => {
    const matchesSearch = u.displayName.toLowerCase().includes(searchTerm.toLowerCase()) || (u.login && u.login.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesDept = filterDeptId ? u.departmentId === filterDeptId : true;
    const matchesGroup = filterGroupId ? u.groupId === filterGroupId : true;
    return matchesSearch && matchesDept && matchesGroup;
  });

  // Derived groups for the selected department filter
  const displayedGroups = filterDeptId ? teacherGroups.filter(g => g.departmentId === filterDeptId) : teacherGroups;

  if (loading) return <div className="p-8 text-gray-500 font-medium">Yuklanmoqda...</div>;

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-4xl font-black text-gray-900 tracking-tight">O'z Talabalarim</h1>
        <p className="text-gray-500 mt-2 text-lg">O'zingiz yaratgan yo'nalishlarga ro'yxatdan o'tganlar.</p>
      </header>

      <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm flex flex-col md:flex-row gap-4 items-center">
        <div className="relative w-full max-w-md">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
          <input
            type="text"
            className="w-full pl-12 pr-6 py-3 rounded-xl bg-gray-50 border border-gray-100 focus:ring-2 focus:ring-indigo-600 font-medium"
            placeholder="Qidirish (ism, login)..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex w-full max-w-md gap-4">
           <select 
              className="flex-1 py-3 px-4 rounded-xl bg-gray-50 border border-gray-100 focus:ring-2 focus:ring-indigo-600 font-medium"
              value={filterDeptId}
              onChange={(e) => {
                setFilterDeptId(e.target.value);
                setFilterGroupId(''); // reset group when dept changes
              }}
           >
             <option value="">Barcha yo'nalishlar</option>
             {teacherDepartments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
           </select>
           <select 
              className="flex-1 py-3 px-4 rounded-xl bg-gray-50 border border-gray-100 focus:ring-2 focus:ring-indigo-600 font-medium"
              value={filterGroupId}
              onChange={(e) => setFilterGroupId(e.target.value)}
           >
             <option value="">Barcha guruhlar</option>
             {displayedGroups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
           </select>
        </div>
      </div>

      <div className="bg-white rounded-3xl border border-gray-100 shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-gray-50 text-gray-400 font-black text-xs uppercase tracking-widest border-b">
                <th className="px-6 py-4 text-left">№</th>
                <th className="px-6 py-4 text-left">F.I.SH</th>
                <th className="px-6 py-4 text-left">Tug'ilgan sana</th>
                <th className="px-6 py-4 text-left">Tel raqam</th>
                <th className="px-6 py-4 text-center">Yo'nalish</th>
                <th className="px-6 py-4 text-center">Guruh</th>
                <th className="px-6 py-4 text-right">Amallar</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filteredUsers.length === 0 && (
                 <tr><td colSpan={7} className="text-center py-10 text-gray-400 font-bold">Talabalar topilmadi.</td></tr>
              )}
              {filteredUsers.map((u, i) => (
                <tr key={u.uid} className="hover:bg-gray-50/50">
                  <td className="px-6 py-4 font-bold text-gray-400">{i + 1}</td>
                  <td className="px-6 py-4 font-black">{u.displayName}</td>
                  <td className="px-6 py-4 font-medium text-sm text-gray-500">{u.birthDate || '-'}</td>
                  <td className="px-6 py-4 font-medium text-sm text-gray-500">{u.phone || '-'}</td>
                  <td className="px-6 py-4 text-center font-bold text-sm text-indigo-600 bg-indigo-50/50">{u.departmentName || '-'}</td>
                  <td className="px-6 py-4 text-center font-bold text-sm text-gray-600">{u.groupName || '-'}</td>
                  <td className="px-6 py-4 text-right">
                    <button onClick={() => deleteSingleUser(u.uid)} className="p-2 text-red-600 hover:bg-red-50 rounded-lg">
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
