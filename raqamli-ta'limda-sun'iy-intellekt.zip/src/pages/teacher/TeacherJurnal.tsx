import { useState, useEffect } from 'react';
import { db } from '../../lib/firebase';
import { collection, getDocs, orderBy, query, deleteDoc, updateDoc, doc, where } from 'firebase/firestore';
import { Enrollment, Department, Group, UserProfile, Course, Test } from '../../types';
import { Loader2, Download, Search, FileText, Trash2, Filter, FileSpreadsheet } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import * as XLSX from 'xlsx';

export default function TeacherJurnal() {
  const { user } = useAuth();
  const [data, setData] = useState<any[]>([]);
  const [testResults, setTestResults] = useState<any[]>([]);
  const [allTests, setAllTests] = useState<{id: string, title: string}[]>([]);
  
  // Teacher's specific data
  const [teacherCourses, setTeacherCourses] = useState<{id: string, name: string}[]>([]);
  const [teacherDepts, setTeacherDepts] = useState<Department[]>([]);
  const [teacherGroups, setTeacherGroups] = useState<Group[]>([]);
  const [studentProfiles, setStudentProfiles] = useState<Record<string, UserProfile>>({});
  
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState<'course' | 'test' | 'exam'>('course');
  
  // Filters
  const [filterDept, setFilterDept] = useState('');
  const [filterGrp, setFilterGrp] = useState('');
  const [filterCourse, setFilterCourse] = useState('');

  useEffect(() => {
    async function load() {
      if (!user) return;
      try {
        // Load Teacher's Depts, Groups, Courses
        const dSnap = await getDocs(query(collection(db, 'departments'), where('creatorId', '==', user.uid)));
        const depts = dSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Department));
        setTeacherDepts(depts);

        const deptIds = depts.map(d => d.id);
        
        const gSnap = await getDocs(query(collection(db, 'groups'), where('creatorId', '==', user.uid)));
        setTeacherGroups(gSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Group)));

        const cSnap = await getDocs(query(collection(db, 'courses'), where('creatorId', '==', user.uid)));
        const coursesMap: Record<string, string> = {};
        const cArr: {id: string, name: string}[] = [];
        cSnap.forEach(d => {
          coursesMap[d.id] = d.data().title;
          cArr.push({id: d.id, name: d.data().title});
        });
        setTeacherCourses(cArr);

        // Load Users mapping (to get their dept/group for filtering)
        const uSnap = await getDocs(collection(db, 'users'));
        const usersMap: Record<string, UserProfile> = {};
        uSnap.forEach(d => {
          usersMap[d.id] = { uid: d.id, ...d.data() } as UserProfile;
        });
        setStudentProfiles(usersMap);

        // Load Enrollments for these courses
        const courseIds = cArr.map(c => c.id);
        const journalMap = new Map();
        
        if (courseIds.length > 0) {
          // split into chunks if > 30, but simplified here:
          const eSnap = await getDocs(query(collection(db, 'enrollments'), where('courseId', 'in', courseIds.slice(0, 30))));
          eSnap.docs.forEach(doc => {
            const en = doc.data() as Enrollment;
            if (!usersMap[en.userId] || usersMap[en.userId].role !== 'student') return;
  
            const key = `${en.userId}_${en.courseId}`;
            if (!journalMap.has(key)) {
              journalMap.set(key, {
                id: doc.id,
                userId: en.userId,
                studentName: usersMap[en.userId].displayName,
                departmentId: usersMap[en.userId].departmentId,
                groupId: usersMap[en.userId].groupId,
                courseId: en.courseId,
                courseName: coursesMap[en.courseId] || '?',
                grades: en.grades,
                progress: en.currentModuleIndex
              });
            } else {
               const existing = journalMap.get(key);
               if (en.currentModuleIndex > existing.progress) {
                   journalMap.set(key, { ...existing, grades: en.grades, progress: en.currentModuleIndex });
               }
            }
          });
          setData(Array.from(journalMap.values()));
        } else {
          setData([]);
        }

        // Fetch tests
        const tSnap = await getDocs(query(collection(db, 'tests'), where('creatorId', '==', user.uid)));
        const tests = tSnap.docs.map(doc => ({ id: doc.id, title: doc.data().title }));
        setAllTests(tests);
        const testIds = tests.map(t => t.id);

        if (testIds.length > 0) {
          const trSnap = await getDocs(query(collection(db, 'testResults'), where('testId', 'in', testIds.slice(0, 30)), orderBy('createdAt', 'desc')));
          const latestMap = new Map();

          trSnap.docs.forEach(doc => {
              const d = doc.data() as any;
              const sp = usersMap[d.userId];
              if (!sp || sp.role !== 'student') return;

              const key = `${d.userId}_${d.testId}`;
              if (!latestMap.has(key)) {
                  latestMap.set(key, {
                    id: doc.id,
                    ...d,
                    studentName: sp?.displayName || d.userName || 'Noma\'lum',
                    departmentId: sp?.departmentId,
                    groupId: sp?.groupId
                  });
              }
          });
          setTestResults(Array.from(latestMap.values()));
        } else {
          setTestResults([]);
        }

      } catch (err) {
        console.error("Xatolik", err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [user]);

  const handleDeleteCourseEnrollment = async (id: string) => {
    if(!confirm("Rostdan o'chirmoqchimisiz?")) return;
    await deleteDoc(doc(db, 'enrollments', id));
    setData(data.filter(d => d.id !== id));
  };

  const handleDeleteTestResult = async (id: string, isFromTable = false) => {
    if(!confirm("Rostdan o'chirmoqchimisiz?")) return;
    await deleteDoc(doc(db, 'testResults', id));
    setTestResults(testResults.filter(d => d.id !== id));
  };
  
  // Filtering Course
  let filteredCourseData = data.filter(d => d.studentName.toLowerCase().includes(searchTerm.toLowerCase()));
  if (filterCourse) filteredCourseData = filteredCourseData.filter(d => d.courseId === filterCourse);
  if (filterDept) filteredCourseData = filteredCourseData.filter(d => d.departmentId === filterDept);
  if (filterGrp) filteredCourseData = filteredCourseData.filter(d => d.groupId === filterGrp);

  // Filtering Tests
  let filteredTestResults = testResults.filter(r => r.studentName.toLowerCase().includes(searchTerm.toLowerCase()) && r.testType !== 'exam');
  if (filterDept) filteredTestResults = filteredTestResults.filter(d => d.departmentId === filterDept);
  if (filterGrp) filteredTestResults = filteredTestResults.filter(d => d.groupId === filterGrp);

  // Filtering Exams
  let filteredExamResults = testResults.filter(r => r.studentName.toLowerCase().includes(searchTerm.toLowerCase()) && r.testType === 'exam');
  if (filterDept) filteredExamResults = filteredExamResults.filter(d => d.departmentId === filterDept);
  if (filterGrp) filteredExamResults = filteredExamResults.filter(d => d.groupId === filterGrp);

  const availableGroups = teacherGroups.filter(g => !filterDept || g.departmentId === filterDept);

  const getResultGrade = (pct: number) => {
    if (pct < 30) return 1;
    if (pct <= 55) return 2;
    if (pct <= 71) return 3;
    if (pct <= 86) return 4;
    return 5;
  };

  const exportToExcel = (type: string) => {
     let exportData: any[] = [];
     let filename = "";

     if (type === 'course') {
        filename = "Kurs_Jurnali.xlsx";
        exportData = filteredCourseData.map((d, i) => ({
           "№": i + 1,
           "F.I.SH": d.studentName,
           "Yo'nalish": teacherDepts.find(x => x.id === d.departmentId)?.name || '-',
           "Guruh": teacherGroups.find(x => x.id === d.groupId)?.name || '-',
           "Kurs": d.courseName,
           "Modul 1": d.grades["m1"] || "-",
           "Modul 2": d.grades["m2"] || "-",
           "Modul 3": d.grades["m3"] || "-",
           "Modul 4": d.grades["m4"] || "-",
           "Yakuniy": d.grades["m5"] || "-",
           "O'rtacha (%)": d.progress + "%"
        }));
     } else if (type === 'test') {
        filename = "Test_Jurnali.xlsx";
        exportData = filteredTestResults.map((r, i) => ({
           "№": i + 1,
           "F.I.SH": r.studentName,
           "Yo'nalish": teacherDepts.find(x => x.id === r.departmentId)?.name || '-',
           "Guruh": teacherGroups.find(x => x.id === r.groupId)?.name || '-',
           "Test": r.testTitle,
           "To'g'ri": r.score,
           "Jami": r.totalQuestions,
           "Foiz (%)": Math.round((r.score / r.totalQuestions) * 100) + "%",
           "Baho": getResultGrade(Math.round((r.score / r.totalQuestions) * 100)),
           "Sana": r.createdAt?.toDate ? r.createdAt.toDate().toLocaleString() : '-'
        }));
     } else if (type === 'exam') {
        filename = "Imtihon_Jurnali.xlsx";
        exportData = filteredExamResults.map((r, i) => ({
           "№": i + 1,
           "F.I.SH": r.studentName,
           "Yo'nalish": teacherDepts.find(x => x.id === r.departmentId)?.name || '-',
           "Guruh": teacherGroups.find(x => x.id === r.groupId)?.name || '-',
           "Imtihon": r.testTitle,
           "Foiz (%)": Math.round((r.score / r.totalQuestions) * 100) + "%",
           "Baho": getResultGrade(Math.round((r.score / r.totalQuestions) * 100)),
           "Sana": r.createdAt?.toDate ? r.createdAt.toDate().toLocaleString() : '-'
        }));
     }

     const worksheet = XLSX.utils.json_to_sheet(exportData);
     const workbook = XLSX.utils.book_new();
     XLSX.utils.book_append_sheet(workbook, worksheet, "Journal");
     XLSX.writeFile(workbook, filename);
  };

  if (loading) return <div className="text-gray-500 font-medium">Jurnal ma'lumotlari yuklanmoqda...</div>;

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-10">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h1 className="text-4xl font-black text-gray-900 tracking-tight">Tashkilot Jurnali</h1>
          <p className="text-gray-500 mt-2 text-lg">O'z kurslar va testlaringiz natijalari.</p>
        </div>
        <div className="flex bg-white rounded-2xl p-1.5 border border-gray-100 shadow-sm">
          <button
            onClick={() => setActiveTab('course')}
            className={`px-6 py-3 rounded-xl font-bold transition-all ${activeTab === 'course' ? 'bg-indigo-600 text-white shadow' : 'text-gray-400 hover:text-gray-600'}`}
          >
            Kurs jurnali
          </button>
          <button
            onClick={() => setActiveTab('test')}
            className={`px-6 py-3 rounded-xl font-bold transition-all ${activeTab === 'test' ? 'bg-indigo-600 text-white shadow' : 'text-gray-400 hover:text-gray-600'}`}
          >
            Test jurnali
          </button>
          <button
            onClick={() => setActiveTab('exam')}
            className={`px-6 py-3 rounded-xl font-bold transition-all ${activeTab === 'exam' ? 'bg-indigo-600 text-white shadow' : 'text-gray-400 hover:text-gray-600'}`}
          >
            Imtihon jurnali
          </button>
        </div>
      </header>

      <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm flex flex-col md:flex-row gap-4 items-center">
        <div className="relative w-full md:w-96 flex-shrink-0">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
          <input
            type="text"
            className="w-full pl-12 pr-6 py-3 rounded-xl bg-gray-50 border border-gray-100 focus:ring-2 focus:ring-indigo-600 font-medium"
            placeholder="Qidirish (Talaba)..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex flex-wrap items-center gap-4 w-full md:w-auto">
          <Filter className="text-gray-400 w-5 h-5 hidden md:block" />
          
          <button 
             onClick={() => exportToExcel(activeTab)}
             className="px-6 py-3 bg-green-600 text-white rounded-xl font-black flex items-center gap-2 shadow-lg shadow-green-100 hover:bg-green-700 transition-all text-sm uppercase"
          >
             <FileSpreadsheet className="w-5 h-5" /> EXCELGA YUKLASH
          </button>
          
          {activeTab === 'course' && (
            <select 
              value={filterCourse} 
              onChange={e => setFilterCourse(e.target.value)}
              className="px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl text-sm font-medium w-full md:w-auto"
            >
              <option value="">Barcha Kurslar</option>
              {teacherCourses.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          )}

          <select 
            value={filterDept} 
            onChange={e => { setFilterDept(e.target.value); setFilterGrp(''); }}
            className="px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl text-sm font-medium w-full md:w-auto"
          >
            <option value="">Barcha yo'nalishlar</option>
            {teacherDepts.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
          </select>
          <select 
            value={filterGrp} 
            onChange={e => setFilterGrp(e.target.value)}
            disabled={!filterDept}
            className="px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl text-sm font-medium w-full md:w-auto disabled:opacity-50"
          >
            <option value="">Barcha guruhlar</option>
            {availableGroups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
          </select>
        </div>
      </div>

      {activeTab === 'course' && (
         <div className="bg-white rounded-3xl border border-gray-100 shadow-xl overflow-hidden">
            <div className="overflow-x-auto">
               <table className="w-full border-collapse">
                  <thead>
                     <tr className="bg-gray-50/50 border-b border-gray-50">
                        <th className="px-6 py-5 text-left text-xs font-black text-gray-400 uppercase tracking-widest whitespace-nowrap">№</th>
                        <th className="px-6 py-5 text-left text-xs font-black text-gray-400 uppercase tracking-widest whitespace-nowrap">F.I.SH</th>
                        <th className="px-6 py-5 text-left text-xs font-black text-gray-400 uppercase tracking-widest whitespace-nowrap">Yo'nalish</th>
                        <th className="px-6 py-5 text-center text-xs font-black text-gray-400 uppercase tracking-widest whitespace-nowrap">Modul 1</th>
                        <th className="px-6 py-5 text-center text-xs font-black text-gray-400 uppercase tracking-widest whitespace-nowrap">Modul 2</th>
                        <th className="px-6 py-5 text-center text-xs font-black text-gray-400 uppercase tracking-widest whitespace-nowrap">Modul 3</th>
                        <th className="px-6 py-5 text-center text-xs font-black text-gray-400 uppercase tracking-widest whitespace-nowrap">Modul 4</th>
                        <th className="px-6 py-5 text-center text-xs font-black text-gray-400 uppercase tracking-widest whitespace-nowrap">Yakuniy</th>
                     </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                     {filteredCourseData.length === 0 && (
                        <tr><td colSpan={8} className="text-center py-10 font-bold text-gray-400">Hech narsa topilmadi</td></tr>
                     )}
                     {filteredCourseData.map((d, i) => {
                        const deptName = teacherDepts.find(x => x.id === d.departmentId)?.name || '-';
                        return (
                           <tr key={i} className="hover:bg-gray-50/30">
                              <td className="px-6 py-4 font-bold text-gray-400">{i + 1}</td>
                              <td className="px-6 py-4 font-black">{d.studentName}</td>
                              <td className="px-6 py-4 font-bold text-sm text-gray-500">{deptName}</td>
                              <td className="px-6 py-4 text-center font-bold text-sm text-gray-600">{d.grades?.["m1"] ? d.grades?.["m1"] + '%' : '-'}</td>
                              <td className="px-6 py-4 text-center font-bold text-sm text-gray-600">{d.grades?.["m2"] ? d.grades?.["m2"] + '%' : '-'}</td>
                              <td className="px-6 py-4 text-center font-bold text-sm text-gray-600">{d.grades?.["m3"] ? d.grades?.["m3"] + '%' : '-'}</td>
                              <td className="px-6 py-4 text-center font-bold text-sm text-gray-600">{d.grades?.["m4"] ? d.grades?.["m4"] + '%' : '-'}</td>
                              <td className="px-6 py-4 text-center font-black">
                                 <span className={`px-3 py-1 rounded-lg ${Number(d.grades?.["m5"] || 0) >= 60 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                    {d.grades?.["m5"] ? d.grades?.["m5"] + '%' : '-'}
                                 </span>
                              </td>
                           </tr>
                        );
                     })}
                  </tbody>
               </table>
            </div>
         </div>
      )}

      {activeTab === 'exam' && (
         <div className="bg-white rounded-3xl border border-gray-100 shadow-xl overflow-hidden">
            <div className="overflow-x-auto">
               <table className="w-full border-collapse">
                  <thead>
                     <tr className="bg-gray-50/50 border-b border-gray-50">
                        <th className="px-6 py-5 text-left text-xs font-black text-gray-400 uppercase tracking-widest">№</th>
                        <th className="px-6 py-5 text-left text-xs font-black text-gray-400 uppercase tracking-widest">F.I.SH</th>
                        <th className="px-6 py-5 text-left text-xs font-black text-gray-400 uppercase tracking-widest">Yo'nalish va Guruh</th>
                        <th className="px-6 py-5 text-left text-xs font-black text-gray-400 uppercase tracking-widest">Imtihon nomi</th>
                        <th className="px-6 py-5 text-center text-xs font-black text-gray-400 uppercase tracking-widest">Natija (5 ball)</th>
                        <th className="px-6 py-5 text-right text-xs font-black text-gray-400 uppercase tracking-widest">Amallar</th>
                     </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                     {filteredExamResults.length === 0 && (
                        <tr><td colSpan={6} className="text-center py-10 font-bold text-gray-400">Hech narsa topilmadi</td></tr>
                     )}
                     {filteredExamResults.map((r, i) => {
                        const pct = Math.round((r.score / r.totalQuestions) * 100);
                        const grade = getResultGrade(pct);
                        const deptName = teacherDepts.find(x => x.id === r.departmentId)?.name || '-';
                        const grpName = teacherGroups.find(x => x.id === r.groupId)?.name || '-';
                        return (
                           <tr key={r.id}>
                              <td className="px-6 py-4 font-bold text-gray-400">{i + 1}</td>
                              <td className="px-6 py-4 font-black">{r.studentName}</td>
                              <td className="px-6 py-4 font-bold text-gray-500 text-sm whitespace-nowrap">{deptName} / {grpName}</td>
                              <td className="px-6 py-4 font-bold text-blue-600">{r.testTitle}</td>
                              <td className="px-6 py-4 text-center">
                                 <span className={`font-black px-6 py-2 rounded-xl text-xl ${grade >= 4 ? 'bg-green-500 text-white' : grade === 3 ? 'bg-yellow-500 text-white' : 'bg-red-500 text-white'}`}>
                                    {grade}
                                 </span>
                              </td>
                              <td className="px-6 py-4 text-right">
                                 <button onClick={() => handleDeleteTestResult(r.id)} className="p-2 text-red-600 hover:bg-red-50 rounded-lg">
                                    <Trash2 className="w-5 h-5"/>
                                 </button>
                              </td>
                           </tr>
                        );
                     })}
                  </tbody>
               </table>
            </div>
         </div>
      )}
      {activeTab === 'test' && (
         <div className="bg-white rounded-3xl border border-gray-100 shadow-xl overflow-hidden">
            <div className="overflow-x-auto">
               <table className="w-full border-collapse">
                  <thead>
                     <tr className="bg-gray-50/50 border-b border-gray-50">
                        <th className="px-6 py-5 text-left text-xs font-black text-gray-400 uppercase tracking-widest">№</th>
                        <th className="px-6 py-5 text-left text-xs font-black text-gray-400 uppercase tracking-widest">F.I.SH</th>
                        <th className="px-6 py-5 text-left text-xs font-black text-gray-400 uppercase tracking-widest">Yo'nalish</th>
                        <th className="px-6 py-5 text-left text-xs font-black text-gray-400 uppercase tracking-widest">Guruh</th>
                        <th className="px-6 py-5 text-center text-xs font-black text-gray-400 uppercase tracking-widest">To'gri / Jami</th>
                        <th className="px-6 py-5 text-center text-xs font-black text-gray-400 uppercase tracking-widest">%</th>
                        <th className="px-6 py-5 text-center text-xs font-black text-gray-400 uppercase tracking-widest">Baho (1-5)</th>
                        <th className="px-6 py-5 text-right text-xs font-black text-gray-400 uppercase tracking-widest">Sana</th>
                        <th className="px-6 py-5 text-right text-xs font-black text-gray-400 uppercase tracking-widest">Amal</th>
                     </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                     {filteredTestResults.length === 0 && (
                        <tr><td colSpan={9} className="text-center py-10 font-bold text-gray-400">Hech narsa topilmadi</td></tr>
                     )}
                     {filteredTestResults.map((r, i) => {
                        const pct = Math.round((r.score / r.totalQuestions) * 100);
                        const grade = getResultGrade(pct);
                        const deptName = teacherDepts.find(x => x.id === r.departmentId)?.name || '-';
                        const grpName = teacherGroups.find(x => x.id === r.groupId)?.name || '-';
                        return (
                           <tr key={r.id}>
                              <td className="px-6 py-4 font-bold text-gray-400">{i + 1}</td>
                              <td className="px-6 py-4 font-black">{r.studentName}</td>
                              <td className="px-6 py-4 font-bold text-gray-500 text-sm whitespace-nowrap">{deptName}</td>
                              <td className="px-6 py-4 font-bold text-gray-500 text-sm whitespace-nowrap">{grpName}</td>
                              <td className="px-6 py-4 text-center font-bold">
                                 {r.score} / {r.totalQuestions}
                              </td>
                              <td className="px-6 py-4 text-center">
                                 <span className={`font-black px-3 py-1 rounded-lg text-sm ${pct >= 60 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                    {pct}%
                                 </span>
                              </td>
                              <td className="px-6 py-4 text-center">
                                 <span className={`font-black px-4 py-1.5 rounded-xl text-lg ${grade >= 4 ? 'bg-green-500 text-white' : grade === 3 ? 'bg-yellow-500 text-white' : 'bg-red-500 text-white'}`}>
                                    {grade}
                                 </span>
                              </td>
                              <td className="px-6 py-4 text-right text-xs font-bold text-gray-500 whitespace-nowrap">
                                 {r.createdAt?.toDate ? r.createdAt.toDate().toLocaleString('uz-UZ') : '-'}
                              </td>
                              <td className="px-6 py-4 text-right">
                                 <button onClick={() => handleDeleteTestResult(r.id, true)} className="p-2 text-red-600 hover:bg-red-50 rounded-lg">
                                    <Trash2 className="w-5 h-5"/>
                                 </button>
                              </td>
                           </tr>
                        );
                     })}
                  </tbody>
               </table>
            </div>
         </div>
      )}
    </div>
  );
}
