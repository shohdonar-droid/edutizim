import React, { useState, useEffect } from 'react';
import { auth, db } from '../lib/firebase';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { useNavigate, Link } from 'react-router-dom';
import { LogIn, Loader2, BrainCircuit } from 'lucide-react';
import { doc, getDoc, setDoc, serverTimestamp, addDoc, collection, query, where, getDocs } from 'firebase/firestore';
import { useAuth } from '../hooks/useAuth';

export default function Login() {
  const [loginField, setLoginField] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [activeRole, setActiveRole] = useState<'admin' | 'teacher' | 'student'>('student');
  const navigate = useNavigate();
  const { refreshUser, user } = useAuth();

  useEffect(() => {
    if (user) {
      navigate(user.role === 'admin' ? '/admin' : (user.role === 'teacher' ? '/teacher' : '/student'));
    }
  }, [user, navigate]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    const trimmedLogin = loginField.trim();
    const loginPass = password;

    const ADMIN_LOGIN = 'Elyorbek';
    const ADMIN_PASS = '1104aA'; 
    const ADMIN_EMAIL = 'elyorbek@admin.uz';

    let emailToAuth = `${trimmedLogin.toLowerCase()}@student.uz`;

    if (trimmedLogin === ADMIN_LOGIN) {
      emailToAuth = ADMIN_EMAIL;
    } else if (trimmedLogin.includes('@')) {
      emailToAuth = trimmedLogin; // allow direct email if they type it
    }

    try {
      let actualEmail = emailToAuth;
      // Agar admin bo'lmasa, baza orqali login/email qidiramiz
      if (trimmedLogin !== ADMIN_LOGIN) {
         const q = query(collection(db, 'users'), where('login', '==', trimmedLogin));
         const snap = await getDocs(q);
         if (!snap.empty) {
            actualEmail = snap.docs[0].data().email || emailToAuth;
         }
      }

      // 1. Dastlab oddiy login qilishga urinamiz
      const res = await signInWithEmailAndPassword(auth, actualEmail, loginPass);
      const userDoc = await getDoc(doc(db, 'users', res.user.uid));
      
      if (userDoc.exists()) {
        const role = userDoc.data().role;
        
        if (role !== activeRole) {
           setError(`Ushbu hisob ${activeRole === 'admin' ? 'Admin' : activeRole === 'teacher' ? 'Tashkilot' : 'Talaba'} profili emas.`);
           setLoading(false);
           await auth.signOut();
           return;
        }

        // Log activity
        try {
          const sessionRef = await addDoc(collection(db, 'activityLogs'), {
            userId: res.user.uid,
            userDisplayName: userDoc.data().displayName,
            role: role,
            loginTime: Date.now(),
            logoutTime: null,
            durationMinutes: 0
          });
          localStorage.setItem('sessionId', sessionRef.id);
          localStorage.setItem('sessionStart', Date.now().toString());
        } catch (e) {}

        await refreshUser();
        navigate(role === 'admin' ? '/admin' : (role === 'teacher' ? '/teacher' : '/student'));
      } else {
        setError('Profil hujjatlari topilmadi. Qaytadan ro\'yxatdan o\'ting.');
        await auth.signOut();
      }
    } catch (err: any) {
      // 2. Agar Firebase'da bunday user yo'q bo'lsa va u hozir qat'iy Admin login/parolni tergan bo'lsa -> SEAMLESS yaratamiz
      if (trimmedLogin === ADMIN_LOGIN && loginPass === ADMIN_PASS && (err.code === 'auth/user-not-found' || err.code === 'auth/invalid-credential')) {
        try {
          const res = await createUserWithEmailAndPassword(auth, ADMIN_EMAIL, loginPass);
          const userDocParams = {
            uid: res.user.uid,
            displayName: `Elyorbek (Admin)`,
            firstName: 'Elyorbek',
            lastName: 'Admin',
            email: ADMIN_EMAIL,
            login: ADMIN_LOGIN,
            role: 'admin',
            createdAt: serverTimestamp(),
          };
          await setDoc(doc(db, 'users', res.user.uid), userDocParams);
          
          try {
            const sessionRef = await addDoc(collection(db, 'activityLogs'), {
              userId: res.user.uid,
              userDisplayName: userDocParams.displayName,
              role: userDocParams.role,
              loginTime: Date.now(),
              logoutTime: null,
              durationMinutes: 0
            });
            localStorage.setItem('sessionId', sessionRef.id);
            localStorage.setItem('sessionStart', Date.now().toString());
          } catch (e) {}
          
          await refreshUser();
          navigate('/admin');
          return; 
        } catch (createErr: any) {
           setError('Admin profilini avtomatik yaratishda xato: ' + createErr.message);
        }
      } else {
         if (err.code === 'auth/invalid-credential' || err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password') {
           setError('Login yoki parol xato kiritildi.');
         } else {
           setError('Xatolik yuz berdi: ' + err.message);
         }
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-64px)] flex items-center justify-center p-4 relative overflow-hidden">
      <div className="max-w-[400px] w-full mac-window relative z-10">
        <div className="h-10 bg-gray-100/80 backdrop-blur-md border-b border-gray-200/50 flex items-center px-4 relative">
          <div className="flex gap-2 z-10">
            <div className="w-3 h-3 rounded-full bg-[#ff5f56] border border-[#e0443e]"></div>
            <div className="w-3 h-3 rounded-full bg-[#ffbd2e] border border-[#dea123]"></div>
            <div className="w-3 h-3 rounded-full bg-[#27c93f] border border-[#1aab29]"></div>
          </div>
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <span className="text-xs font-semibold text-gray-500">Tizimga kirish</span>
          </div>
        </div>

        <div className="p-8">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-blue-50 mb-6 shadow-sm border border-blue-100/50">
              <BrainCircuit className="h-8 w-8 text-[#007aff]" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 tracking-tight mb-2">Tizimga xush kelibsiz</h2>
            <p className="text-gray-500 text-sm font-medium">Davom etish uchun ma'lumotlarni kiriting</p>
          </div>

          <div className="flex p-1.5 bg-gray-100/80 rounded-2xl mb-8 gap-1 border border-gray-200/50">
            <button
              onClick={() => setActiveRole('admin')}
              className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all ${
                activeRole === 'admin' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Admin
            </button>
            <button
              onClick={() => setActiveRole('teacher')}
              className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all ${
                activeRole === 'teacher' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Tashkilot
            </button>
            <button
              onClick={() => setActiveRole('student')}
              className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all ${
                activeRole === 'student' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Talaba
            </button>
          </div>

          <form onSubmit={handleLogin} className="space-y-5">
            <div className="space-y-1.5">
              <label className="block text-sm font-semibold text-gray-700 ml-1">Login</label>
              <input
                type="text"
                required
                className="block w-full px-4 py-3 rounded-xl bg-white border border-gray-200 focus:outline-none focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 transition-all text-gray-900 shadow-sm placeholder-gray-400 font-medium"
                placeholder="Login..."
                value={loginField}
                onChange={(e) => setLoginField(e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <label className="block text-sm font-semibold text-gray-700 ml-1">Parol</label>
              <input
                type="password"
                required
                className="block w-full px-4 py-3 rounded-xl bg-white border border-gray-200 focus:outline-none focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 transition-all text-gray-900 shadow-sm placeholder-gray-400 font-medium"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>

            {error && (
              <div className="text-red-600 text-xs font-semibold text-center bg-red-50 py-3 rounded-xl border border-red-100 px-4">
                {error}
              </div>
            )}

            <button
              disabled={loading}
              type="submit"
              className="w-full flex justify-center items-center gap-2 mac-btn-primary mt-2 disabled:opacity-50"
            >
              {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <LogIn className="h-5 w-5" />}
              Kirish
            </button>
          </form>

          <div className="mt-8 text-center">
            <p className="text-gray-500 font-medium text-sm">
              Hisobingiz yo'qmi?{' '}
              <Link to="/register" className="text-[#007aff] font-semibold hover:underline ml-1 pointer-events-auto">
                Ro'yxatdan o'tish
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
