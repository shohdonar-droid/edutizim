import React, { useState, useEffect } from 'react';
import { auth, db } from '../lib/firebase';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { useNavigate, Link } from 'react-router-dom';
import { UserPlus, Loader2, BrainCircuit } from 'lucide-react';
import { doc, setDoc, serverTimestamp, getDocs, collection, query, where } from 'firebase/firestore';
import { useAuth } from '../hooks/useAuth';
import { UserProfile } from '../types';

export default function Register() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    middleName: '',
    login: '',
    password: '',
    teacherId: '',
  });
  const [teachers, setTeachers] = useState<UserProfile[]>([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { refreshUser } = useAuth();

  useEffect(() => {
    async function loadTeachers() {
      try {
        const tSnap = await getDocs(query(collection(db, 'users'), where('role', '==', 'teacher')));
        const ts = tSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as any)) as UserProfile[];
        ts.sort((a,b) => (a.displayName || '').localeCompare(b.displayName || '', 'uz-UZ'));
        setTeachers(ts);
      } catch (err) {
        console.error(err);
      }
    }
    loadTeachers();
  }, []);

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    const trimmedLogin = formData.login.trim();
    if (!trimmedLogin) {
      setError("Login bo'sh bo'lishi mumkin emas.");
      setLoading(false);
      return;
    }

    try {
      // Baza orqali login ni tekshiramiz
      const q = query(collection(db, 'users'), where('login', '==', trimmedLogin));
      const qSnap = await getDocs(q);
      if (!qSnap.empty) {
         setError("Bu login allaqachon band. Iltimos boshqa login tanlang.");
         setLoading(false);
         return;
      }
    } catch (e) {
      console.error(e);
    }

    let pass = formData.password;
    let role = 'student';

    let emailToUse = `${trimmedLogin.toLowerCase()}_${Date.now()}@student.uz`;

    const teacherName = teachers.find(t => t.uid === formData.teacherId)?.displayName || '';

    try {
      const res = await createUserWithEmailAndPassword(auth, emailToUse, pass);
      
      await setDoc(doc(db, 'users', res.user.uid), {
        uid: res.user.uid,
        displayName: `${formData.lastName} ${formData.firstName} ${formData.middleName}`,
        firstName: formData.firstName,
        lastName: formData.lastName,
        middleName: formData.middleName,
        email: emailToUse,
        login: trimmedLogin,
        password: pass, // Requested behavior for simulated environment resets
        teacherId: formData.teacherId,
        teacherName: teacherName,
        departmentId: '',
        departmentName: '',
        groupId: '',
        groupName: '',
        role: role,
        createdAt: serverTimestamp(),
      });

      await refreshUser();
      navigate('/student');
    } catch (err: any) {
      if (err.code === 'auth/weak-password') {
        setError("Parol kamida 6 ta belgidan iborat bo'lishi kerak.");
      } else if (err.code === 'auth/email-already-in-use') {
        setError('Bu login allaqachon band. Iltimos boshqa login tanlang.');
      } else if (err.code === 'auth/invalid-email') {
         setError('Yaroqsiz login formati kiritildi. Faqat harf va sonlardan foydalaning.');
      } else {
        setError('Xatolik yuz berdi: ' + err.message);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-64px)] flex items-center justify-center p-4 relative overflow-hidden my-8">
      <div className="max-w-[450px] w-full mac-window relative z-10">
        
        <div className="h-10 bg-gray-100/80 backdrop-blur-md border-b border-gray-200/50 flex items-center px-4 relative">
          <div className="flex gap-2 z-10">
            <div className="w-3 h-3 rounded-full bg-[#ff5f56] border border-[#e0443e]"></div>
            <div className="w-3 h-3 rounded-full bg-[#ffbd2e] border border-[#dea123]"></div>
            <div className="w-3 h-3 rounded-full bg-[#27c93f] border border-[#1aab29]"></div>
          </div>
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <span className="text-xs font-semibold text-gray-500">Ro'yxatdan o'tish</span>
          </div>
        </div>

        <div className="p-8">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-blue-50 mb-6 shadow-sm border border-blue-100/50">
              <BrainCircuit className="h-8 w-8 text-[#007aff]" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 tracking-tight mb-2">Yangi hisob yaratish</h2>
            <p className="text-gray-500 text-sm font-medium">Platformaga qo'shiling va o'qishni boshlang</p>
          </div>

          <form onSubmit={handleRegister} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5 col-span-2 md:col-span-1">
                <label className="block text-sm font-semibold text-gray-700 ml-1">Familiya</label>
                <input
                  type="text"
                  required
                  className="block w-full px-4 py-3 rounded-xl bg-white border border-gray-200 focus:outline-none focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 transition-all text-gray-900 shadow-sm placeholder-gray-400 font-medium text-sm"
                  value={formData.lastName}
                  onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                />
              </div>
              <div className="space-y-1.5 col-span-2 md:col-span-1">
                <label className="block text-sm font-semibold text-gray-700 ml-1">Ism</label>
                <input
                  type="text"
                  required
                  className="block w-full px-4 py-3 rounded-xl bg-white border border-gray-200 focus:outline-none focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 transition-all text-gray-900 shadow-sm placeholder-gray-400 font-medium text-sm"
                  value={formData.firstName}
                  onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-sm font-semibold text-gray-700 ml-1">Otasining ismi</label>
              <input
                type="text"
                className="block w-full px-4 py-3 rounded-xl bg-white border border-gray-200 focus:outline-none focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 transition-all text-gray-900 shadow-sm placeholder-gray-400 font-medium text-sm"
                value={formData.middleName}
                onChange={(e) => setFormData({ ...formData, middleName: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5 col-span-2 md:col-span-1">
                <label className="block text-sm font-semibold text-gray-700 ml-1">Login</label>
                <input
                  type="text"
                  required
                  className="block w-full px-4 py-3 rounded-xl bg-white border border-gray-200 focus:outline-none focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 transition-all text-gray-900 shadow-sm placeholder-gray-400 font-medium text-sm"
                  value={formData.login}
                  onChange={(e) => setFormData({ ...formData, login: e.target.value })}
                />
              </div>
              <div className="space-y-1.5 col-span-2 md:col-span-1">
                <label className="block text-sm font-semibold text-gray-700 ml-1">Parol</label>
                <input
                  type="password"
                  required
                  className="block w-full px-4 py-3 rounded-xl bg-white border border-gray-200 focus:outline-none focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 transition-all text-gray-900 shadow-sm placeholder-gray-400 font-medium text-sm"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-sm font-semibold text-gray-700 ml-1">Tashkilotni tanlang</label>
              <select
                required
                className="block w-full px-4 py-3 rounded-xl bg-white border border-gray-200 focus:outline-none focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 transition-all text-gray-900 shadow-sm font-medium text-sm"
                value={formData.teacherId}
                onChange={e => setFormData({ ...formData, teacherId: e.target.value })}
              >
                <option value="">Tanlang</option>
                {teachers.map(t => <option key={t.uid} value={t.uid}>{t.displayName}</option>)}
              </select>
            </div>

            {error && (
              <div className="text-red-600 text-xs font-semibold text-center bg-red-50 py-3 rounded-xl border border-red-100 px-4">
                {error}
              </div>
            )}

            <button
              disabled={loading}
              type="submit"
              className="w-full flex justify-center items-center gap-2 mac-btn-primary mt-4 disabled:opacity-50"
            >
              {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <UserPlus className="h-5 w-5" />}
              Ro'yxatdan o'tish
            </button>
          </form>

          <div className="mt-6 text-center pt-6 border-t border-gray-100">
            <p className="text-gray-500 font-medium text-sm">
              Hisobingiz bormi?{' '}
              <Link to="/login" className="text-[#007aff] font-semibold hover:underline ml-1 pointer-events-auto">
                Kirish
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
