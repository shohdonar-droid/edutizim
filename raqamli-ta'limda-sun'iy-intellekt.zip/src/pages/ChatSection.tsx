import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../hooks/useAuth';
import { db } from '../lib/firebase';
import { collection, addDoc, query, orderBy, onSnapshot, where, Timestamp, limit, getDocs, or, writeBatch, doc, getDoc } from 'firebase/firestore';
import { Message, UserProfile } from '../types';
import { Send, Loader2, User as UserIcon, Bell, MessageSquare, X } from 'lucide-react';
import { format } from 'date-fns';

export default function ChatSection() {
  const { user, isAdmin } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const [selectedContactId, setSelectedContactId] = useState<string | null>(null);
  const [contacts, setContacts] = useState<UserProfile[]>([]);
  const [unreadCounts, setUnreadCounts] = useState<Record<string, number>>({});

  // Load contacts
  useEffect(() => {
    if (!user) return;
    if (isAdmin) {
      // Admin sees everyone (Teachers and all students)
      const q = query(collection(db, 'users'), where('role', 'in', ['teacher', 'student']));
      const unsub = onSnapshot(q, (snap) => {
        const users = snap.docs.map(d => ({ id: d.id, ...d.data() } as any));
        users.sort((a, b) => {
          if (a.role === 'teacher' && b.role !== 'teacher') return -1;
          if (a.role !== 'teacher' && b.role === 'teacher') return 1;
          return (a.displayName || '').localeCompare(b.displayName || '', 'uz-UZ');
        });
        setContacts(users);
      }, (err) => console.error(err));
      return unsub;
    } else {
      // Student or Teacher contacts
      const fetchNonAdminContacts = async () => {
         const newContacts: any[] = [];
         
         // 1. Fetch Admins filtering purely for ELYORBEK
         const aSnap = await getDocs(query(collection(db, 'users'), where('role', '==', 'admin')));
         const elyorbek = aSnap.docs
           .map(d => ({ id: d.id, ...d.data() } as any))
           .filter(a => a.displayName?.toUpperCase().includes('ELYORBEK'));
         newContacts.push(...elyorbek);

         if (user.role === 'student') {
            // Student sees their organization
            if (user.teacherId) {
               const tDoc = await getDoc(doc(db, 'users', user.teacherId));
               if (tDoc.exists()) {
                  newContacts.push({ id: tDoc.id, ...tDoc.data() });
               }
            }
         } else if (user.role === 'teacher') {
            // Teacher sees their students
            const sSnap = await getDocs(query(collection(db, 'users'), where('role', '==', 'student'), where('teacherId', '==', user.uid)));
            const students = sSnap.docs.map(d => ({ id: d.id, ...d.data() }));
            newContacts.push(...students);
         }
         
         setContacts(newContacts);
         if (newContacts.length > 0 && !selectedContactId) {
            setSelectedContactId(newContacts[0].id || newContacts[0].uid);
         }
      }
      fetchNonAdminContacts();
    }
  }, [user, isAdmin]);

  // unread listener
  useEffect(() => {
    if (user) {
      const q = query(
        collection(db, 'messages'),
        where('receiverId', '==', user.uid),
        where('isRead', '==', false)
      );
      const unsub = onSnapshot(q, (snap) => {
        const counts: Record<string, number> = {};
        snap.docs.forEach(doc => {
          const senderId = doc.data().senderId;
          counts[senderId] = (counts[senderId] || 0) + 1;
        });
        setUnreadCounts(counts);
      }, (err) => console.error(err));
      return unsub;
    }
  }, [user]);

  // Messages listener
  useEffect(() => {
    if (!user || !selectedContactId) {
       setMessages([]);
       return;
    }

    const q1 = query(
      collection(db, 'messages'),
      where('senderId', '==', user.uid),
      where('receiverId', '==', selectedContactId)
    );
    const q2 = query(
      collection(db, 'messages'),
      where('senderId', '==', selectedContactId),
      where('receiverId', '==', user.uid)
    );

    let msgs1: Message[] = [];
    let msgs2: Message[] = [];

    const processMessages = () => {
      // Merge, remove duplicates, sort
      const allMsgs = [...msgs1, ...msgs2];
      const unique = Array.from(new Map(allMsgs.map(m => [m.id, m])).values());
      unique.sort((a, b) => {
        const t1 = a.timestamp?.toMillis ? a.timestamp.toMillis() : 0;
        const t2 = b.timestamp?.toMillis ? b.timestamp.toMillis() : 0;
        return t1 - t2;
      });

      setMessages(unique);
      setTimeout(() => scrollRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);

      // Mark unread messages as read
      const unreadMsgs = unique.filter(m => m.receiverId === user.uid && !m.isRead);
      if (unreadMsgs.length > 0) {
        try {
          const batch = writeBatch(db);
          unreadMsgs.forEach(m => {
            const msgRef = doc(db, 'messages', m.id);
            batch.update(msgRef, { isRead: true });
          });
          batch.commit().catch(e => console.error(e));
        } catch (e) {
          console.error("Xabarlarni o'qilgan qilishda xatolik:", e);
        }
      }
    };

    const unsub1 = onSnapshot(q1, (snap) => {
      msgs1 = snap.docs.map(d => ({ id: d.id, ...d.data() } as Message));
      processMessages();
    }, (err) => console.error("Listen Error 1:", err));

    const unsub2 = onSnapshot(q2, (snap) => {
      msgs2 = snap.docs.map(d => ({ id: d.id, ...d.data() } as Message));
      processMessages();
    }, (err) => console.error("Listen Error 2:", err));

    return () => {
      unsub1();
      unsub2();
    };
  }, [user, selectedContactId]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || !user || !selectedContactId) return;

    setLoading(true);
    try {
      await addDoc(collection(db, 'messages'), {
        senderId: user.uid,
        receiverId: selectedContactId,
        text: text.trim(),
        timestamp: Timestamp.now(),
        isRead: false,
      });
      setText('');
    } catch (err: any) {
      console.error("Send Error:", err);
      alert("Xabar yuborishda xatolik: " + err.message);
    } finally {
      setLoading(false);
    }
  };

  const currentContact = contacts.find(c => (c.id || c.uid) === selectedContactId);

  return (
    <div className="flex flex-col h-[700px] bg-white rounded-3xl border border-gray-100 shadow-xl overflow-hidden mt-6">
      <header className="px-8 py-5 border-b border-gray-50 flex items-center justify-between bg-white z-10">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600">
            <MessageSquare className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-900 tracking-tight">
              {isAdmin ? "Chat (Talaba va Tashkilotlar bilan)" : "Chat"}
            </h2>
            <p className="text-xs text-green-500 font-bold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
              Onlayn
            </p>
          </div>
        </div>
        {(!isAdmin && window.innerWidth < 768) || (isAdmin && selectedContactId) ? (
          <button onClick={() => setSelectedContactId(null)} className="text-xs text-blue-600 font-bold hover:underline md:hidden">
            Ortga
          </button>
        ) : null}
      </header>

      <div className="flex flex-1 min-w-0">
        <div className={`w-full md:w-1/3 border-r border-gray-50 flex flex-col ${selectedContactId ? 'hidden md:flex' : 'flex'}`}>
          <div className="p-4 border-b border-gray-50 flex items-center justify-between">
             <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Suhbatdoshlar</span>
             {Object.values(unreadCounts as Record<string, number>).reduce((a, b) => a + b, 0) > 0 && (
                <span className="bg-red-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                   {Object.values(unreadCounts as Record<string, number>).reduce((a, b) => a + b, 0)} yangi
                </span>
             )}
          </div>
          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {contacts.map(c => {
              const cid = c.uid || c.id || '';
              const unread = unreadCounts[cid] || 0;
              const isSelected = selectedContactId === cid;
              return (
                <button
                  key={cid}
                  onClick={() => setSelectedContactId(cid)}
                  className={`w-full p-3 rounded-2xl flex items-center justify-between gap-3 transition-all border ${
                    isSelected ? 'bg-blue-50 border-blue-100' : 'border-transparent hover:bg-gray-50 hover:border-gray-100'
                  }`}
                >
                  <div className="flex items-center gap-3 overflow-hidden">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${isSelected ? 'bg-blue-200 text-blue-700' : 'bg-gray-100 text-gray-400'}`}>
                      <UserIcon className="h-5 w-5" />
                    </div>
                    <div className="text-left overflow-hidden">
                      <p className="font-bold text-gray-800 text-sm truncate">{c.displayName || 'Ismsiz'}</p>
                      <p className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">
                        {c.role === 'teacher' ? 'Tashkilot' : c.role === 'admin' ? 'Admin' : (c.isAnonymousContact ? 'Saytdan xabar' : 'Talaba')}
                      </p>
                    </div>
                  </div>
                  {unread > 0 && (
                     <span className="min-w-[24px] h-[24px] rounded-full bg-red-500 text-white text-[10px] font-black flex items-center justify-center px-1">
                      {unread}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        <div className={`flex-1 flex flex-col min-w-0 ${!selectedContactId ? 'hidden md:flex' : 'flex'}`}>
          {selectedContactId ? (
            <>
              <div className="p-4 border-b border-gray-50 bg-white flex items-center gap-3">
                 <button onClick={() => setSelectedContactId(null)} className="md:hidden p-2 text-gray-500 hover:bg-gray-100 rounded-lg">
                    <X className="h-5 w-5" />
                 </button>
                 <div>
                    <h3 className="font-bold text-gray-900">{currentContact?.displayName || 'Ismsiz'}</h3>
                    <p className="text-xs text-gray-400">{currentContact?.role === 'admin' ? 'Tizim administratori' : currentContact?.role === 'teacher' ? 'Tashkilot profili' : 'Foydalanuvchi'}</p>
                 </div>
              </div>
              <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-6">
                {messages.length > 0 ? messages.map((m) => {
                  const isMe = m.senderId === user?.uid;
                  return (
                    <div key={m.id} className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                      <div className={`max-w-[85%] md:max-w-[70%] px-5 py-3.5 rounded-2xl shadow-sm ${
                        isMe ? 'bg-blue-600 text-white rounded-tr-none' : 'bg-gray-50 text-gray-900 rounded-tl-none border border-gray-100'
                      }`}>
                        <p className="text-sm leading-relaxed whitespace-pre-wrap">{m.text}</p>
                      </div>
                      <span className="text-[10px] text-gray-400 font-bold mt-1.5 uppercase tracking-tighter">
                        {m.timestamp?.toDate ? format(m.timestamp.toDate(), 'HH:mm') : ''}
                      </span>
                    </div>
                  );
                }) : (
                  <div className="flex flex-col items-center justify-center h-full text-center p-10 opacity-40">
                    <div className="w-20 h-20 rounded-full bg-gray-100 flex items-center justify-center mb-4">
                      <MessageSquare className="h-10 w-10 text-gray-300" />
                    </div>
                    <p className="text-gray-500 font-medium italic">Xabarlar mavjud emas. Birinchi bo'lib yozing!</p>
                  </div>
                )}
                <div ref={scrollRef} />
              </div>

              <footer className="p-4 md:p-6 border-t border-gray-50 bg-white">
                <form onSubmit={handleSend} className="flex gap-3">
                  <input
                    type="text"
                    className="flex-1 px-5 py-3.5 rounded-2xl bg-gray-50 border-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all text-sm font-medium"
                    placeholder="Xabar yozing..."
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                  />
                  <button
                    disabled={loading || !text.trim()}
                    type="submit"
                    className="p-4 rounded-2xl bg-blue-600 text-white shadow-lg shadow-blue-100 hover:bg-blue-700 transition-all disabled:opacity-50"
                  >
                    {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Send className="h-5 w-5" />}
                  </button>
                </form>
              </footer>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-gray-400 p-10 text-center">
              <MessageSquare className="h-16 w-16 mb-4 text-gray-200" />
              <p className="font-medium text-gray-500">Chapdan suhbatdoshni tanlang</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
