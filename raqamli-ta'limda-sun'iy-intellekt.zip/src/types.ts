export type UserRole = 'admin' | 'student' | 'teacher';

export interface Department {
  id: string;
  name: string;
  creatorId?: string;
  createdAt: any;
}

export interface Group {
  id: string;
  departmentId: string;
  name: string;
  creatorId?: string;
  createdAt: any;
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  role: UserRole;
  photoURL?: string;
  phone?: string;
  birthDate?: string;
  firstName?: string;
  lastName?: string;
  middleName?: string;
  address?: string;
  login?: string;
  password?: string;
  ball?: number;
  ballPrice?: number;
  totalIncome?: number;
  aiTestLimit?: number;
  spentBalls?: number;
  lastIncomeDate?: any;
  departmentId?: string;
  groupId?: string;
  departmentName?: string;
  groupName?: string;
  teacherId?: string;
  teacherName?: string;
  createdAt: any;
}

export interface Module {
  id: string;
  title: string;
  content: string; // Markdown content
  videoUrl?: string; // Add video url
  testId?: string;
}

export interface Course {
  id: string;
  title: string;
  thumbnail: string;
  description: string;
  modules: Module[];
  creatorId?: string;
  creatorRole?: string;
  creatorName?: string;
  departmentIds?: string[];
  groupIds?: string[];
  organizationIds?: string[];
  createdAt: any;
}

export interface Question {
  id: string;
  text: string;
  options: string[];
  correctIdx: number;
}

export interface GenerationRule {
  subject: string;
  context: string;
  count: number;
}

export interface Test {
  id: string;
  title: string;
  questions: Question[]; 
  type: 'module' | 'topic' | 'exam';
  moduleId?: string;
  courseId?: string;
  startTime?: any;
  endTime?: any;
  generationRules?: GenerationRule[];
  isPublished?: boolean;
  creatorId?: string;
  creatorRole?: string;
  organizationIds?: string[];
  departmentId?: string;
  groupId?: string;
  departmentIds?: string[];
  groupIds?: string[];
  maxAttempts?: number;
  createdAt?: any;
}

export interface Enrollment {
  id: string;
  userId: string;
  courseId: string;
  currentModuleIndex: number;
  grades: Record<string, number>; // moduleId -> score (%)
  completed: boolean;
  certificateId?: string;
  lastAccessed: any;
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  text: string;
  timestamp: any;
  isRead: boolean;
}

export interface SiteContent {
  header?: {
    logoUrl?: string;
    siteName?: string;
    bgClass?: string;
    textClass?: string;
  };
  hero: {
    rightImage: string;
    rightBadge: string; // "Yangilik" etc
    rightText: string;
    detailHtml?: string; // Rich text / HTML for detail page
    detailFiles?: Array<{ name: string; url: string; type: string }>; // PDF, PPT etc
  };
  banners: Array<{
    url: string;
    type: 'image' | 'video';
    title?: string;
    text?: string;
    description?: string;
  }>;
  footer: {
    logoUrl?: string;
    description?: string;
    top?: string;
    address?: string;
    phone?: string;
    email?: string;
    workingHours?: string;
    telegram?: string;
    instagram?: string;
    youtube?: string;
    bottom?: string;
  };
  contact?: {
    title?: string;
    description?: string;
    email?: string;
    phone?: string;
    address?: string;
  };
}
